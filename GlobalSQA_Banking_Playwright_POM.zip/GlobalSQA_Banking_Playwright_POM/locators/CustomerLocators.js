class CustomerLocators {
  static customerName = 'span.fontBig';
  static accountSelect = 'select[ng-model="accountNo"]';

  static depositButton = 'button:has-text("Deposit")';
  static withdrawButton = 'button:has-text("Withdraw")';
  static transactionsButton = 'button:has-text("Transactions")';
  static logoutButton = 'button:has-text("Logout")';

  static amountInput = 'input[ng-model="amount"]';
  static transactionSubmit = 'button[type="submit"]';

  static transactionTable = 'table.table.table-bordered.table-striped';
  static notification = '.error, .alert, span[ng-show]';
}

module.exports = { CustomerLocators };
