class LoginLocators {
  static customerLoginButton = 'button:has-text("Customer Login")';
  static managerLoginButton = 'button:has-text("Bank Manager Login")';
  static customerSelect = 'select[ng-model="custId"]';
  static customerLoginSubmit = 'button[type="submit"]:has-text("Login")';
}

module.exports = { LoginLocators };
