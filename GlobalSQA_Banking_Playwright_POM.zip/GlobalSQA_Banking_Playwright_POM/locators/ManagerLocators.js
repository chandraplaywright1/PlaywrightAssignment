class ManagerLocators {
  static addCustomerButton = 'button:has-text("Add Customer")';
  static openAccountButton = 'button:has-text("Open Account")';
  static customersButton = 'button:has-text("Customers")';

  static firstNameInput = 'input[ng-model="fName"]';
  static lastNameInput = 'input[ng-model="lName"]';
  static postCodeInput = 'input[ng-model="postCd"]';
  static addCustomerSubmit = 'button[type="submit"]:has-text("Add Customer")';

  static accountCustomerSelect = 'select[ng-model="custId"]';
  static currencySelect = 'select[ng-model="currency"]';
  static processAccountButton = 'button[type="submit"]:has-text("Process")';

  static customerTable = 'table';
}

module.exports = { ManagerLocators };
