class CommonLocators {
  static homeButton = 'button:has-text("Home")';
  static logoutButton = 'button:has-text("Logout"):visible';
}

module.exports = { CommonLocators };
