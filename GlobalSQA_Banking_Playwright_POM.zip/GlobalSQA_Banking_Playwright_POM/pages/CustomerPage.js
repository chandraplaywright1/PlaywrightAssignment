const { BasePage } = require('./BasePage');
const { CustomerLocators } = require('../locators/CustomerLocators');
const { CommonLocators } = require('../locators/CommonLocators');

class CustomerPage extends BasePage {
  constructor(page) {
    super(page);
  }

  async selectAccountByText(accountText) {
    const select = this.page.locator(CustomerLocators.accountSelect);
    await select.waitFor({ state: 'visible' });

    const option = select.locator('option', { hasText: accountText }).first();
    if (await option.count()) {
      const value = await option.getAttribute('value');
      if (value) {
        await select.selectOption(value);
      }
    }
  }

  async deposit(amount) {
    await this.click(CustomerLocators.depositButton);

    const amountInput = this.page.locator(CustomerLocators.amountInput);
    await amountInput.waitFor({ state: 'visible', timeout: 15 * 1000 });
    await amountInput.fill(String(amount));

    this.page.once('dialog', async dialog => {
      await dialog.accept();
    });

    await this.page.locator(CustomerLocators.transactionSubmit).click();
    await this.page.waitForTimeout(1000);
  }

  async withdraw(amount) {
    await this.click(CustomerLocators.withdrawButton);

    const amountInput = this.page.locator(CustomerLocators.amountInput);
    await amountInput.waitFor({ state: 'visible', timeout: 15 * 1000 });
    await amountInput.fill(String(amount));

    this.page.once('dialog', async dialog => {
      await dialog.accept();
    });

    await this.page.locator(CustomerLocators.transactionSubmit).click();
    await this.page.waitForTimeout(1000);
  }

  async openTransactions() {
    await this.click(CustomerLocators.transactionsButton);
    await this.page.locator(CustomerLocators.transactionTable).waitFor({
      state: 'visible',
      timeout: 15 * 1000
    });
  }

  async getTransactionTableText() {
    const table = this.page.locator(CustomerLocators.transactionTable);
    await table.waitFor({ state: 'visible', timeout: 15 * 1000 });
    return (await table.innerText()).trim();
  }

  async getCustomerName() {
    return this.getText(CustomerLocators.customerName);
  }

  async logout() {
    await this.click(CustomerLocators.logoutButton);
  }

  async isCustomerDashboardDisplayed() {
    return this.isVisible(CustomerLocators.depositButton);
  }
}

module.exports = { CustomerPage };
