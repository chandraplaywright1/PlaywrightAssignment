const { BasePage } = require('./BasePage');
const { ManagerLocators } = require('../locators/ManagerLocators');
const { CommonLocators } = require('../locators/CommonLocators');

class ManagerPage extends BasePage {
  constructor(page) {
    super(page);
  }

  async openAddCustomer() {
    await this.click(ManagerLocators.addCustomerButton);
  }

  async openAccount() {
    await this.click(ManagerLocators.openAccountButton);
  }

  async openCustomers() {
    await this.click(ManagerLocators.customersButton);
  }

  async logout() {
    await this.click(CommonLocators.homeButton);
  }

  async isManagerDashboardDisplayed() {
    return this.isVisible(ManagerLocators.addCustomerButton);
  }
}

module.exports = { ManagerPage };
