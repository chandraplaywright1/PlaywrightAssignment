const { BasePage } = require('./BasePage');
const { ManagerLocators } = require('../locators/ManagerLocators');

class OpenAccountPage extends BasePage {
  constructor(page) {
    super(page);
  }

  async openAccountForCustomer(customerName, currency = 'Dollar') {
    const customerSelect = this.page.locator(ManagerLocators.accountCustomerSelect);
    await customerSelect.waitFor({ state: 'visible' });

    const option = customerSelect.locator('option', { hasText: customerName }).first();
    await option.waitFor({ state: 'attached' });

    const customerValue = await option.getAttribute('value');
    if (!customerValue) {
      throw new Error(`Unable to find customer value for ${customerName}`);
    }

    await customerSelect.selectOption(customerValue);
    await this.selectOption(ManagerLocators.currencySelect, currency);

    this.page.once('dialog', async dialog => {
      await dialog.accept();
    });

    await this.click(ManagerLocators.processAccountButton);
    await this.page.waitForTimeout(500);
  }

  async isOpenAccountPageDisplayed() {
    return this.isVisible(ManagerLocators.accountCustomerSelect);
  }
}

module.exports = { OpenAccountPage };
