const { BasePage } = require('./BasePage');
const { LoginLocators } = require('../locators/LoginLocators');

class LoginPage extends BasePage {
  constructor(page) {
    super(page);
  }

  async open() {
    const loginButton = this.page.locator(LoginLocators.managerLoginButton);

    for (let attempt = 1; attempt <= 2; attempt += 1) {
      await this.page.goto('/angularJs-protractor/BankingProject/#/login', {
        waitUntil: 'domcontentloaded'
      });

      try {
        await loginButton.waitFor({ state: 'visible', timeout: 15 * 1000 });
        return;
      } catch (error) {
        if (attempt === 2) {
          throw error;
        }
      }
    }
  }

  async loginAsManager() {
    await this.click(LoginLocators.managerLoginButton);
  }

  async openCustomerLogin() {
    await this.click(LoginLocators.customerLoginButton);
  }

  async selectCustomer(customerName) {
    const select = this.page.locator(LoginLocators.customerSelect);
    await select.waitFor({ state: 'visible' });

    const option = select.locator('option', { hasText: customerName }).first();
    await option.waitFor({ state: 'attached' });
    const value = await option.getAttribute('value');

    if (!value) {
      throw new Error(`Customer option found but no value was available for: ${customerName}`);
    }

    await select.selectOption(value);
  }

  async loginCustomer(customerName) {
    await this.openCustomerLogin();
    await this.selectCustomer(customerName);
    await this.click(LoginLocators.customerLoginSubmit);
  }
}

module.exports = { LoginPage };
