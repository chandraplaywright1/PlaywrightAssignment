const { BasePage } = require('./BasePage');
const { ManagerLocators } = require('../locators/ManagerLocators');

class AddCustomerPage extends BasePage {
  constructor(page) {
    super(page);
  }

  async addCustomer(firstName, lastName, postCode) {
    await this.fill(ManagerLocators.firstNameInput, firstName);
    await this.fill(ManagerLocators.lastNameInput, lastName);
    await this.fill(ManagerLocators.postCodeInput, postCode);

    this.page.once('dialog', async dialog => {
      await dialog.accept();
    });

    await this.click(ManagerLocators.addCustomerSubmit);

    // AngularJS updates the customer form asynchronously.
    await this.page.waitForTimeout(500);
  }

  async isAddCustomerFormDisplayed() {
    return this.isVisible(ManagerLocators.firstNameInput);
  }
}

module.exports = { AddCustomerPage };
