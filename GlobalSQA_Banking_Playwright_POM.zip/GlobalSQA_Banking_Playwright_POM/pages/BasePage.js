class BasePage {
  constructor(page) {
    this.page = page;
  }

  async click(locator) {
    await this.page.locator(locator).click();
  }

  async fill(locator, value) {
    await this.page.locator(locator).fill(String(value));
  }

  async selectOption(locator, value) {
    await this.page.locator(locator).selectOption(value);
  }

  async getText(locator) {
    return (await this.page.locator(locator).first().innerText()).trim();
  }

  async isVisible(locator) {
    return this.page.locator(locator).first().isVisible();
  }

  async waitForVisible(locator) {
    await this.page.locator(locator).first().waitFor({ state: 'visible' });
  }

  async waitForUrlPart(urlPart) {
    await this.page.waitForURL(new RegExp(urlPart.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  }

  async goHome() {
    await this.page.goto('/');
  }
}

module.exports = { BasePage };
