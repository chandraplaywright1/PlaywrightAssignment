# GlobalSQA Banking Project - Playwright JavaScript POM

This project automates the GlobalSQA AngularJS Banking Project using Playwright with JavaScript and the Page Object Model (POM).

## Application

https://www.globalsqa.com/angularJs-protractor/BankingProject/#/login

The application provides separate Manager and Customer journeys. The framework focuses on:

1. Manager login
2. Manager dashboard navigation
3. Add customer
4. Open account for a customer
5. Customer login
6. Customer dashboard
7. Deposit / withdrawal transactions
8. Transaction history
9. Logout

## Framework structure

```text
GlobalSQA_Banking_Playwright_POM/
│
├── locators/
│   ├── LoginLocators.js
│   ├── ManagerLocators.js
│   ├── CustomerLocators.js
│   └── CommonLocators.js
│
├── pages/
│   ├── BasePage.js
│   ├── LoginPage.js
│   ├── ManagerPage.js
│   ├── AddCustomerPage.js
│   ├── OpenAccountPage.js
│   └── CustomerPage.js
│
├── hooks/
│   └── testHooks.js
│
├── testData/
│   └── bankingData.json
│
├── tests/
│   └── banking.spec.js
│
├── playwright.config.js
├── package.json
└── README.md
```

## Prerequisites

- Node.js 18+
- npm

## Installation

```bash
npm install
npx playwright install chromium
```

## Run all tests

```bash
npm test
```

## Run headed

```bash
npm run test:headed
```

## Debug

```bash
npm run test:debug
```

## Playwright UI mode

```bash
npm run test:ui
```

## HTML report

```bash
npm run report
```

## Notes

The GlobalSQA Banking application is a public practice application. Its data is shared/server-side and can change between runs. For that reason, the framework generates a unique customer name using a timestamp before adding a customer.

The selectors are intentionally centralized under `locators/`; page classes contain business actions rather than scattered CSS/XPath selectors.

The framework uses Playwright's role/text/label locators where practical and CSS selectors where the AngularJS demo's markup requires them.

## Main test flow

```text
Open Login
   |
   +--> Manager Login
          |
          +--> Manager Dashboard
                  |
                  +--> Add Customer
                  |      |
                  |      +--> Capture generated customer
                  |
                  +--> Open Account
                         |
                         +--> Select customer
                         +--> Select currency
                         +--> Capture account number
                                 |
                                 v
                         Customer Login
                                 |
                                 +--> Deposit
                                 +--> Withdraw
                                 +--> Verify Transactions
                                 +--> Logout
```
