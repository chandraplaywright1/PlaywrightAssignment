const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  const customerFirstName = 'PWUser' + Date.now();
  const customerLastName = 'Automation';
  const customerName = customerFirstName + ' ' + customerLastName;

  await page.goto('https://www.globalsqa.com/angularJs-protractor/BankingProject/#/login');
  await page.locator('button:has-text("Bank Manager Login")').click();
  await page.locator('button:has-text("Add Customer")').click();
  await page.locator('input[ng-model="fName"]').fill(customerFirstName);
  await page.locator('input[ng-model="lName"]').fill(customerLastName);
  await page.locator('input[ng-model="postCd"]').fill('560001');
  page.once('dialog', d => d.accept());
  await page.locator('button[type="submit"]:has-text("Add Customer")').click();
  await page.locator('button:has-text("Open Account")').click();
  const customerSelect = page.locator('select[ng-model="custId"]');
  await customerSelect.waitFor({ state: 'visible' });
  const value = await customerSelect.locator('option', { hasText: customerName }).first().getAttribute('value');
  await customerSelect.selectOption(value);
  await page.locator('select[ng-model="currency"]').selectOption('Dollar');
  page.once('dialog', d => d.accept());
  await page.locator('button[type="submit"]:has-text("Process")').click();
  await page.locator('button:has-text("Home")').click();
  await page.locator('button:has-text("Customer Login")').click();
  await page.locator('select').selectOption({ label: customerName });
  await page.locator('button[type="submit"]').click();

  await page.locator('button:has-text("Deposit")').click();
  const depositInput = page.locator('input[ng-model="amount"]');
  await depositInput.waitFor({ state: 'visible' });
  await depositInput.fill('1000');
  page.once('dialog', d => d.accept());
  await page.locator('button[type="submit"]').click();
  await page.waitForTimeout(2000);
  console.log('AFTER DEPOSIT');
  console.log(await page.locator('table.table.table-bordered.table-striped').innerText());

  await page.locator('button:has-text("Back")').click();
  await page.locator('button:has-text("Withdraw")').click();
  const withdrawInput = page.locator('input[ng-model="amount"]');
  await withdrawInput.waitFor({ state: 'visible' });
  await withdrawInput.fill('250');
  page.once('dialog', d => d.accept());
  await page.locator('button[type="submit"]').click();
  await page.waitForTimeout(2000);
  console.log('AFTER WITHDRAW');
  console.log(await page.locator('table.table.table-bordered.table-striped').innerText());

  await browser.close();
})();
