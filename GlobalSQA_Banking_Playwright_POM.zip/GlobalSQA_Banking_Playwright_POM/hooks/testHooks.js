const { test: base } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');
const { ManagerPage } = require('../pages/ManagerPage');
const { AddCustomerPage } = require('../pages/AddCustomerPage');
const { OpenAccountPage } = require('../pages/OpenAccountPage');
const { CustomerPage } = require('../pages/CustomerPage');

const test = base.extend({
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },

  managerPage: async ({ page }, use) => {
    await use(new ManagerPage(page));
  },

  addCustomerPage: async ({ page }, use) => {
    await use(new AddCustomerPage(page));
  },

  openAccountPage: async ({ page }, use) => {
    await use(new OpenAccountPage(page));
  },

  customerPage: async ({ page }, use) => {
    await use(new CustomerPage(page));
  }
});

module.exports = { test };
