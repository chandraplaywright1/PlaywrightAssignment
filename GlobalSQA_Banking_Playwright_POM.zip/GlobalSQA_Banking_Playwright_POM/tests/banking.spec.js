const { expect } = require('@playwright/test');
const { test } = require('../hooks/testHooks');
const data = require('../testData/bankingData.json');

test.describe('GlobalSQA Banking Project - Manager and Customer Flow', () => {
  let customerName;
  let customerFirstName;
  let customerLastName;

  test.beforeEach(async ({ loginPage }) => {
    await loginPage.open();
  });

  test('TC01 - Manager login and dashboard', async ({ loginPage, managerPage }) => {
    await loginPage.loginAsManager();

    await expect.poll(
      async () => managerPage.isManagerDashboardDisplayed(),
      { message: 'Manager dashboard should be displayed after manager login' }
    ).toBeTruthy();

    await expect(managerPage.page).toHaveURL(/manager/);
  });

  test('TC02 - Add customer and open account', async ({
    loginPage,
    managerPage,
    addCustomerPage,
    openAccountPage
  }) => {
    await loginPage.loginAsManager();

    customerFirstName = `${data.customer.firstNamePrefix}${Date.now()}`;
    customerLastName = data.customer.lastName;
    customerName = `${customerFirstName} ${customerLastName}`;

    await managerPage.openAddCustomer();

    await expect.poll(
      async () => addCustomerPage.isAddCustomerFormDisplayed()
    ).toBeTruthy();

    await addCustomerPage.addCustomer(
      customerFirstName,
      customerLastName,
      data.customer.postCode
    );

    await managerPage.openAccount();

    await expect.poll(
      async () => openAccountPage.isOpenAccountPageDisplayed()
    ).toBeTruthy();

    await openAccountPage.openAccountForCustomer(
      customerName,
      data.customer.currency
    );

    await managerPage.openCustomers();
    await expect(managerPage.page.locator('table')).toContainText(customerFirstName);
  });

  test('TC03 - Customer login, deposit, withdrawal and transaction history', async ({
    loginPage,
    managerPage,
    addCustomerPage,
    openAccountPage,
    customerPage
  }) => {
    // Create a unique customer and account in this test so it is independently runnable.
    await loginPage.loginAsManager();

    customerFirstName = `${data.customer.firstNamePrefix}${Date.now()}`;
    customerLastName = data.customer.lastName;
    customerName = `${customerFirstName} ${customerLastName}`;

    await managerPage.openAddCustomer();
    await addCustomerPage.addCustomer(
      customerFirstName,
      customerLastName,
      data.customer.postCode
    );

    await managerPage.openAccount();
    await openAccountPage.openAccountForCustomer(
      customerName,
      data.customer.currency
    );

    // Return to login page through logout.
    await managerPage.logout();
    await loginPage.loginCustomer(customerName);

    await expect.poll(
      async () => customerPage.isCustomerDashboardDisplayed(),
      { timeout: 15 * 1000 }
    ).toBeTruthy();

    await expect(customerPage.getCustomerName()).resolves.toContain(customerFirstName);

    await customerPage.deposit(data.customer.depositAmount);
    await customerPage.withdraw(data.customer.withdrawAmount);
    await customerPage.openTransactions();

    const transactions = await customerPage.getTransactionTableText();

    expect(transactions).toContain(data.customer.depositAmount);
    expect(transactions).toContain(data.customer.withdrawAmount);

    await customerPage.logout();
  });
});
