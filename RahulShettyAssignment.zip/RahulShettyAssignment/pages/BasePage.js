class BasePage {
  constructor(page) {
    this.page = page;
  }

  async navigate(path = '/') {
    await this.page.goto(path);
  }

  async getTitle() {
    return this.page.title();
  }

  async isVisible(locator) {
    return locator.isVisible();
  }

  async click(locator) {
    await locator.click();
  }

  async fill(locator, value) {
    await locator.fill(value);
  }

  async selectOption(locator, value) {
    await locator.selectOption(value);
  }

  async takeScreenshot(filePath) {
    await this.page.screenshot({ path: filePath, fullPage: true });
  }
}

module.exports = { BasePage };
