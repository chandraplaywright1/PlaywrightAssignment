const { expect } = require('@playwright/test');
const { BasePage } = require('./BasePage');
const loginData = require('../testData/loginData.json');
const { LoginPageLocators } = require('../locators/LoginPageLocators');

class LoginPage extends BasePage {
  constructor(page) {
    super(page);

    this.username = page.locator(LoginPageLocators.username);
    this.password = page.locator(LoginPageLocators.password);
    this.roleDropdown = page.locator(LoginPageLocators.roleDropdown);
    this.radioButtons = page.locator(LoginPageLocators.radioButtons);
    this.termsCheckbox = page.locator(LoginPageLocators.termsCheckbox);
    this.loginButton = page.locator(LoginPageLocators.loginButton);
    this.roleModal = page.locator(LoginPageLocators.roleModal);
    this.roleModalOkayButton = page.locator(LoginPageLocators.roleModalOkayButton);
    this.loginError = page.locator(LoginPageLocators.loginError);
    this.postLoginContent = page.locator(LoginPageLocators.postLoginContent);
  }

  async open() {
    await this.navigate(loginData.url);
  }

  async enterUsername(username) {
    await this.fill(this.username, username);
  }

  async enterPassword(password) {
    await this.fill(this.password, password);
  }

  async selectRole(roleValue) {
    await this.selectOption(this.roleDropdown, roleValue);
  }

  async selectRadioOption(value) {
    const radio = this.page.locator(
      `${LoginPageLocators.radioButtons}[value="${value}"]`
    );
    await radio.check();
    await this.dismissRoleModal(true);
  }

  async dismissRoleModal(waitForModal = false) {
    if (waitForModal) {
      await this.roleModal
        .waitFor({ state: 'visible', timeout: 3000 })
        .catch(() => {});
    }

    if (await this.roleModal.isVisible()) {
      await this.roleModalOkayButton.evaluate(button => button.click());
      await this.roleModal.evaluate(modal => {
        modal.classList.remove('show');
        modal.style.display = 'none';
        document.body.classList.remove('modal-open');
        document.querySelectorAll('.modal-backdrop').forEach(backdrop => backdrop.remove());
      });
    }
  }

  async isRadioSelected(value) {
    const radio = this.page.locator(
      `${LoginPageLocators.radioButtons}[value="${value}"]`
    );
    return radio.isChecked();
  }

  async acceptTerms() {
    await this.dismissRoleModal();
    if (!(await this.termsCheckbox.isChecked())) {
      await this.termsCheckbox.check();
    }
  }

  async isTermsAccepted() {
    return this.termsCheckbox.isChecked();
  }

  async clickLogin() {
    await this.loginButton.click();
  }

  async login({ username, password, role, radioValue, acceptTerms = true }) {
    await this.enterUsername(username);
    await this.enterPassword(password);

    if (role) {
      await this.selectRole(role);
    }

    if (radioValue) {
      await this.selectRadioOption(radioValue);
    }

    if (acceptTerms) {
      await this.acceptTerms();
    }

    await this.clickLogin();
  }

  async isLoginErrorVisible() {
    return this.loginError.isVisible();
  }

  async getLoginErrorText() {
    return (await this.loginError.textContent()).trim();
  }

  async waitForLoginResult() {
    await this.page.waitForLoadState('domcontentloaded');
  }
}

module.exports = { LoginPage };
