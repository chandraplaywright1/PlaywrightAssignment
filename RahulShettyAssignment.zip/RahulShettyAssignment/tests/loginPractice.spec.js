const { test, expect } = require('../hooks/testHooks');
const { LoginPage } = require('../pages/LoginPage');
const loginData = require('../testData/loginData.json');

test.describe('Rahul Shetty Academy - Login Practice', () => {
  let loginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    await loginPage.open();
  });

  test('TC01 - Verify login practice page loads successfully', async ({ page }) => {
    await expect(page).toHaveURL(/loginpagePractise/);
    await expect(loginPage.username).toBeVisible();
    await expect(loginPage.password).toBeVisible();
    await expect(loginPage.loginButton).toBeVisible();
  });

  test('TC02 - Verify radio button selection', async () => {
    await loginPage.selectRadioOption(loginData.uiData.radioValue);

    await expect(
      loginPage.page.locator(
        `input[type="radio"][value="${loginData.uiData.radioValue}"]`
      )
    ).toBeChecked();
  });

  test('TC03 - Verify role dropdown selection', async () => {
    await loginPage.selectRole(loginData.uiData.role);

    await expect(loginPage.roleDropdown).toHaveValue(loginData.uiData.role);
  });

  test('TC04 - Verify terms checkbox can be selected', async () => {
    await loginPage.acceptTerms();

    await expect(loginPage.termsCheckbox).toBeChecked();
  });

  test('TC05 - Verify invalid login validation', async () => {
    await loginPage.login({
      username: loginData.invalidUser.username,
      password: loginData.invalidUser.password,
      role: loginData.uiData.role,
      radioValue: loginData.uiData.radioValue,
      acceptTerms: true
    });

    await expect(loginPage.loginError).toBeVisible();
    await expect(loginPage.loginError).toContainText(
      loginData.uiData.expectedInvalidLoginMessage
    );
  });

  test('TC06 - Verify login using configured valid credentials', async ({ page }) => {
    await loginPage.login({
      username: loginData.validUser.username,
      password: loginData.validUser.password,
      role: loginData.uiData.role,
      radioValue: loginData.uiData.radioValue,
      acceptTerms: true
    });

    await loginPage.waitForLoginResult();

    // The exact post-login destination/content can change on the training site.
    // The primary assertion verifies that the invalid-login error is not displayed.
    await expect(loginPage.loginError).not.toBeVisible();

    // Capture final URL for easier troubleshooting if the site's flow changes.
    console.log(`Post-login URL: ${page.url()}`);
  });
});
