# Rahul Shetty Academy - Playwright JavaScript POM Framework

A reusable Playwright JavaScript Page Object Model framework for:

`https://rahulshettyacademy.com/loginpagePractice/`

The example covers:
- Login form validation
- Radio buttons
- Role dropdown
- Terms checkbox
- Positive/negative login scenarios
- JSON-driven test data
- Hooks/fixtures
- Centralized locators
- Reusable BasePage methods
- HTML report, screenshots, video and trace on failure

## Project structure

```text
rahul-shetty-playwright-pom/
├── locators/
│   └── LoginPageLocators.js
├── pages/
│   ├── BasePage.js
│   └── LoginPage.js
├── hooks/
│   └── testHooks.js
├── testData/
│   └── loginData.json
├── tests/
│   └── loginPractice.spec.js
├── playwright.config.js
├── package.json
├── .gitignore
└── README.md
```

## Prerequisites

- Node.js 18+
- npm
- Internet access to the practice application

## Install

```bash
npm install
npx playwright install chromium
```

## Execute

Headless:

```bash
npm test
```

Headed:

```bash
npm run test:headed
```

Chromium only:

```bash
npm run test:chromium
```

Debug:

```bash
npm run test:debug
```

Open HTML report:

```bash
npm run report
```

## Framework design

### Locators
All UI selectors are stored in `locators/LoginPageLocators.js`. Page classes consume these selectors, so selector changes do not require changes in test files.

### BasePage
Contains common browser/page actions such as navigation, title retrieval, visibility checks and screenshot support.

### Page classes
`pages/LoginPage.js` contains business-level actions:
- enterUsername()
- enterPassword()
- selectRole()
- selectRadioOption()
- acceptTerms()
- clickLogin()
- login()
- isLoginErrorVisible()
- getLoginErrorText()

### Hooks
`hooks/testHooks.js` exports a custom Playwright fixture. It creates a fresh browser page, navigates to the configured application URL before every test, and closes the page after every test.

### Test data
`testData/loginData.json` contains credentials and UI test values. No credentials are hard-coded in the test spec.

## Notes about the practice site

The practice page is a third-party training application. UI markup can change independently of this project. If a selector changes, update only `locators/LoginPageLocators.js`.

The sample credentials and expected validation message are kept in JSON so they can be updated without changing test logic.

## Test scenarios included

1. Verify login page loads.
2. Verify radio button selection.
3. Verify role dropdown selection.
4. Verify terms checkbox selection.
5. Verify invalid login validation.
6. Verify login flow with the configured valid credentials.

If the training site's valid credentials or post-login behavior changes, update `testData/loginData.json` and the corresponding assertion in the page/test.

## Recommended next enhancements

- Allure reporting
- Environment-specific config (`dev`, `qa`, `stage`)
- API helper layer
- Authentication fixture/storage state
- CI pipeline with GitHub Actions/Jenkins
- Excel/CSV data provider
- Accessibility checks
- Cross-browser projects (Firefox/WebKit)
