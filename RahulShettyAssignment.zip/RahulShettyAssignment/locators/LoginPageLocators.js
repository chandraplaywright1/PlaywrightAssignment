/**
 * Centralized locators for the Rahul Shetty Academy login practice page.
 * Keep selectors here; do not duplicate them in test files.
 */
const LoginPageLocators = {
  username: '#username',
  password: '#password',

  // The practice page uses a native select for role selection.
  roleDropdown: 'select.form-control',

  // Radio buttons are grouped by name on the practice page.
  radioButtons: 'input[type="radio"]',

  termsCheckbox: '#terms',
  loginButton: '#signInBtn',
  roleModal: '#myModal',
  roleModalOkayButton: '#myModal button:has-text("Okay")',

  // Login validation/error container.
  loginError: '.alert-danger',

  // Common post-login content marker used by the practice application.
  postLoginContent: '.container'
};

module.exports = { LoginPageLocators };
