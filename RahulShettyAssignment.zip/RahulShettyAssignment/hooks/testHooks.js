const { test: base, expect } = require('@playwright/test');

const test = base.extend({
  page: async ({ page }, use) => {
    await page.setViewportSize({ width: 1440, height: 900 });

    await use(page);

    // Page/browser context cleanup is managed by Playwright's fixture lifecycle.
    // This hook can be extended later for logs, screenshots, DB cleanup, etc.
  }
});

module.exports = { test, expect };
