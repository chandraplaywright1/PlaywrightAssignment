# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: saucedemo-flow.spec.js >> SauceDemo - End-to-End Shopping Flow >> standard user can login, add product, checkout and complete order
- Location: tests\saucedemo-flow.spec.js:8:3

# Error details

```
ReferenceError: page is not defined
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "passed"
Received: "failed"
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]: Swag Labs
  - main [ref=e5]:
    - form "Login" [ref=e9]:
      - textbox "Username" [active] [ref=e11]: standard_user
      - textbox "Password" [ref=e13]
      - button "Login" [ref=e15] [cursor=pointer]
    - generic [ref=e17]:
      - generic [ref=e18]:
        - heading "Accepted usernames are:" [level=4] [ref=e19]
        - text: standard_userlocked_out_userproblem_userperformance_glitch_usererror_uservisual_user
      - generic [ref=e20]:
        - heading "Password for all users:" [level=4] [ref=e21]
        - text: secret_sauce
```

# Test source

```ts
  1  | const { expect } = require('@playwright/test');
  2  | const { LoginPage } = require('../pages/LoginPage');
  3  | const { ProductsPage } = require('../pages/ProductsPage');
  4  | const { CartPage } = require('../pages/CartPage');
  5  | const { CheckoutPage } = require('../pages/CheckoutPage');
  6  | const { ConfirmationPage } = require('../pages/ConfirmationPage');
  7  | 
  8  | function registerHooks(test) {
  9  |   test.beforeEach(async ({ page }, testInfo) => {
  10 |     testInfo.attachments = testInfo.attachments || [];
  11 | 
  12 |     page.loginPage = new LoginPage(page);
  13 |     page.productsPage = new ProductsPage(page);
  14 |     page.cartPage = new CartPage(page);
  15 |     page.checkoutPage = new CheckoutPage(page);
  16 |     page.confirmationPage = new ConfirmationPage(page);
  17 | 
  18 |     await page.loginPage.navigate('/');
  19 |   });
  20 | 
  21 |   test.afterEach(async ({ page }, testInfo) => {
  22 |     const status = testInfo.status;
  23 |     const expected = testInfo.expectedStatus;
  24 | 
  25 |     if (status !== expected) {
  26 |       console.log(`Test failed: ${testInfo.title}`);
  27 |     }
  28 | 
  29 |     // Playwright config automatically retains screenshot/video/trace on failure.
  30 |     // This hook is intentionally lightweight so it can be reused across suites.
> 31 |     expect.soft(status).toBe(expected);
     |                         ^ Error: expect(received).toBe(expected) // Object.is equality
  32 |   });
  33 | }
  34 | 
  35 | module.exports = { registerHooks };
```