const { expect } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');
const { ProductsPage } = require('../pages/ProductsPage');
const { CartPage } = require('../pages/CartPage');
const { CheckoutPage } = require('../pages/CheckoutPage');
const { ConfirmationPage } = require('../pages/ConfirmationPage');

function registerHooks(test) {
  test.beforeEach(async ({ page }, testInfo) => {
    testInfo.attachments = testInfo.attachments || [];

    page.loginPage = new LoginPage(page);
    page.productsPage = new ProductsPage(page);
    page.cartPage = new CartPage(page);
    page.checkoutPage = new CheckoutPage(page);
    page.confirmationPage = new ConfirmationPage(page);

    await page.loginPage.navigate('/');
  });

  test.afterEach(async ({ page }, testInfo) => {
    const status = testInfo.status;
    const expected = testInfo.expectedStatus;

    if (status !== expected) {
      console.log(`Test failed: ${testInfo.title}`);
    }

    // Playwright config automatically retains screenshot/video/trace on failure.
    // This hook is intentionally lightweight so it can be reused across suites.
    expect.soft(status).toBe(expected);
  });
}

module.exports = { registerHooks };