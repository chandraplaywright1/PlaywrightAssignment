const { test, expect } = require('@playwright/test');
const { registerHooks } = require('./hooks');
const { testData } = require('../utils/testData');

registerHooks(test);

test.describe('SauceDemo - Negative Login', () => {
  const lockedOutUser = testData.users.find(
    user => user.username === 'locked_out_user'
  );

  test('locked out user receives the documented error message', async ({ page }) => {
    await page.loginPage.login(
      lockedOutUser.username,
      lockedOutUser.password
    );

    await expect(page.loginPage.errorMessage).toBeVisible();
    await expect(page.loginPage.errorMessage).toContainText(
      lockedOutUser.expectedError
    );

    await expect(page).toHaveURL(/saucedemo\.com\/?$/);
  });
});