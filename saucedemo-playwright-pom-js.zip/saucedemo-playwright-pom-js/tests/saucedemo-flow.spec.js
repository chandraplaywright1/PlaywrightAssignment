const { test, expect } = require('@playwright/test');
const { registerHooks } = require('./hooks');
const { testData } = require('../utils/testData');

registerHooks(test);

test.describe('SauceDemo - End-to-End Shopping Flow', () => {
  test('standard user can login, add product, checkout and complete order', async ({ page }) => {
    const user = testData.users.find(item => item.username === 'standard_user');
    const customer = testData.checkoutCustomer;
    const product = testData.products.standardFlowProduct;

    await page.loginPage.login(user.username, user.password);

    await expect(page.productsPage.pageTitle).toHaveText('Products');
    await page.productsPage.addProductToCart(product);
    await expect(page.productsPage.cartBadge).toHaveText('1');

    await page.productsPage.openCart();
    await expect(page.cartPage.pageTitle).toHaveText('Your Cart');
    await expect.poll(() => page.cartPage.verifyProductInCart(product)).toBe(true);

    await page.cartPage.checkout();
    await expect(page.checkoutPage.pageTitle).toHaveText('Checkout: Your Information');

    await page.checkoutPage.fillCustomerDetails(
      customer.firstName,
      customer.lastName,
      customer.postalCode
    );

    await page.checkoutPage.continueToOverview();
    await expect(page.checkoutPage.pageTitle).toHaveText('Checkout: Overview');

    await page.checkoutPage.finishOrder();

    await expect(page.confirmationPage.completeHeader).toHaveText('Thank you for your order!');
    const confirmation = await page.confirmationPage.verifyOrderConfirmation();
    expect(confirmation.text).toContain('Your order has been dispatched');
  });

  test.describe('Additional supported users', () => {
    const additionalUsers = ['problem_user', 'performance_glitch_user'];

    for (const username of additionalUsers) {
      test(`${username} can login successfully`, async ({ page }) => {
        const user = testData.users.find(item => item.username === username);

        await page.loginPage.login(user.username, user.password);

        await expect(page.productsPage.pageTitle).toHaveText('Products');
      });
    }
  });
});