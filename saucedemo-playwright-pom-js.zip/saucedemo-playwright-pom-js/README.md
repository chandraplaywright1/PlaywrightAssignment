# SauceDemo Playwright JavaScript - Page Object Model

A maintainable Playwright Test framework using JavaScript, Page Object Model (POM), reusable Base Page methods, hooks, and JSON-driven test data.

## Application

- URL: https://www.saucedemo.com/
- Demo users include standard, locked-out, problem, and performance-glitch users.
- Password used by the supplied test data: `secret_sauce`

## Framework structure

```text
saucedemo-playwright-pom-js/
├── package.json
├── playwright.config.js
├── README.md
├── pages/
│   ├── BasePage.js
│   ├── LoginPage.js
│   ├── ProductsPage.js
│   ├── CartPage.js
│   ├── CheckoutPage.js
│   └── ConfirmationPage.js
├── test-data/
│   └── users.json
├── tests/
│   ├── hooks.js
│   ├── saucedemo-flow.spec.js
│   └── negative-login.spec.js
└── utils/
    └── testData.js
```

## Page Objects

### BasePage
Common reusable methods:
- navigate()
- click()
- fill()
- getText()
- isVisible()
- getPageTitle()

### LoginPage
Locators/actions for:
- Username
- Password
- Login button
- Login error
- login()

### ProductsPage
Locators/actions for:
- Product inventory
- Add-to-cart buttons
- Cart icon
- Product title
- addProductToCart()
- openCart()

### CartPage
Locators/actions for:
- Cart items
- Checkout button
- continue shopping
- verifyProductInCart()

### CheckoutPage
Locators/actions for:
- First name
- Last name
- Postal code
- Continue
- Finish
- fillCustomerDetails()
- continueToOverview()
- finishOrder()

### ConfirmationPage
Locators/actions for:
- Complete header
- Complete text
- Back Home button
- verifyOrderConfirmation()

## Test data

All user data is stored in `test-data/users.json`.

The supplied matrix is represented as:

| username | password | expectedError |
|---|---|---|
| standard_user | secret_sauce | empty |
| locked_out_user | secret_sauce | Sorry, this user has been locked out. |
| problem_user | secret_sauce | empty |
| performance_glitch_user | secret_sauce | empty |

## Hooks

`tests/hooks.js` contains reusable Playwright hooks:
- beforeEach: creates page objects and navigates to the application
- afterEach: logs test completion and preserves Playwright failure artifacts

## Installation

Prerequisite:
- Node.js 18+ recommended

Run:

```bash
npm install
npx playwright install
```

## Execute tests

Run all tests:

```bash
npm test
```

Run smoke/end-to-end flow:

```bash
npm run test:smoke
```

Run negative login test:

```bash
npm run test:negative
```

Run headed:

```bash
npm run test:headed
```

Debug:

```bash
npm run test:debug
```

Open HTML report:

```bash
npm run report
```

## Covered automation scenarios

### Positive end-to-end
1. Open SauceDemo
2. Login as `standard_user`
3. Verify Products page
4. Add product to cart
5. Open cart
6. Verify product
7. Checkout
8. Enter customer details
9. Continue to order overview
10. Finish order
11. Verify order confirmation

### Negative login
1. Login using `locked_out_user`
2. Verify the documented error:
   `Sorry, this user has been locked out.`

### Additional users
The data-driven suite also validates successful login for:
- `problem_user`
- `performance_glitch_user`

These users are intentionally retained in the JSON so additional product/cart behavior tests can be added without changing the framework.

## Design notes

- Locators are kept inside page classes.
- Tests contain business flow/assertions rather than CSS/XPath details.
- Test data is externalized to JSON.
- Page objects are composed through the reusable hooks fixture.
- `data-test` attributes are preferred where SauceDemo exposes them.
- Playwright captures screenshot/video/trace on failure according to the configuration.
