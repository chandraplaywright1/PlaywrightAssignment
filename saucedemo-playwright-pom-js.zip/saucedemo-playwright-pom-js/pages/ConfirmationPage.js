const { BasePage } = require('./BasePage');

class ConfirmationPage extends BasePage {
  constructor(page) {
    super(page);

    this.completeHeader = page.locator('[data-test="complete-header"]');
    this.completeText = page.locator('[data-test="complete-text"]');
    this.backHomeButton = page.locator('[data-test="back-to-products"]');
  }

  async verifyOrderConfirmation() {
    return {
      header: (await this.getText(this.completeHeader))?.trim(),
      text: (await this.getText(this.completeText))?.trim()
    };
  }

  async backToProducts() {
    await this.backHomeButton.click();
  }
}

module.exports = { ConfirmationPage };