class BasePage {
  constructor(page) {
    this.page = page;
  }

  async navigate(path = '/') {
    await this.page.goto(path);
  }

  async click(locator) {
    await locator.click();
    await page.waitForTimeout(2000);
  }

  async fill(locator, value) {
    await locator.fill(value);
    await page.waitForTimeout(2000);
  }

  async getText(locator) {
    return locator.textContent();
   
  }

  async isVisible(locator) {
    return locator.isVisible();

  }

  async getPageTitle() {
    return this.page.title();
  }
}

module.exports = { BasePage };