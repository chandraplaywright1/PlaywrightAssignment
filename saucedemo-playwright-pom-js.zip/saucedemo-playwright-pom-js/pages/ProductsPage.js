const { BasePage } = require('./BasePage');

class ProductsPage extends BasePage {
  constructor(page) {
    super(page);

    this.pageTitle = page.locator('[data-test="title"]');
    this.inventoryContainer = page.locator('[data-test="inventory-container"]');
    this.cartLink = page.locator('[data-test="shopping-cart-link"]');
    this.cartBadge = page.locator('[data-test="shopping-cart-badge"]');
  }

  productCard(productName) {
    return this.page.locator('.inventory_item', {
      has: this.page.locator('.inventory_item_name', { hasText: productName })
    });
  }

  addToCartButton(productName) {
    return this.productCard(productName).locator('button[data-test^="add-to-cart"]');
  }

  async verifyProductsPage() {
    await this.pageTitle.waitFor({ state: 'visible' });
    return this.pageTitle.textContent();
  }

  async addProductToCart(productName) {
    await this.addToCartButton(productName).click();
  }

  async openCart() {
    await this.cartLink.click();
  }

  async getCartCount() {
    return (await this.cartBadge.textContent())?.trim();
  }
}

module.exports = { ProductsPage };