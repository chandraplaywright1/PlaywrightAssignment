const testData = require('../test-data/users.json');

function getUser(username) {
  const user = testData.users.find(item => item.username === username);

  if (!user) {
    throw new Error(`User '${username}' was not found in test data.`);
  }

  return user;
}

module.exports = {
  testData,
  getUser
};