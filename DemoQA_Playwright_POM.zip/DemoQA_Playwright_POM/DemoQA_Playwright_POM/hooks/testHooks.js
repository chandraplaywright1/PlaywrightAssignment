const { test: base } = require('@playwright/test');

const pages = {
    TextBoxPage: '../pages/TextBoxPage',
    CheckBoxPage: '../pages/CheckBoxPage',
    RadioButtonPage: '../pages/RadioButtonPage',
    WebTablesPage: '../pages/WebTablesPage',
    PracticeFormPage: '../pages/PracticeFormPage',
    AlertsPage: '../pages/AlertsPage',
    FramesPage: '../pages/FramesPage',
    DatePickerPage: '../pages/DatePickerPage',
    SliderPage: '../pages/SliderPage',
    TabsPage: '../pages/TabsPage',
};

const fixtures = {};

for (const [k, v] of Object.entries(pages)) {
    fixtures[k.charAt(0).toLowerCase() + k.slice(1)] = async ({ page }, use) => {
        const C = require(v)[k];
        await use(new C(page));
    };
}

const test = base.extend(fixtures);

module.exports = { test };