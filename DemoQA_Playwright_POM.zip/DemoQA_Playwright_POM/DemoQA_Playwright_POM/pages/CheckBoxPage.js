const{BasePage}=require('./BasePage');
const{CheckBoxLocators:L}=require('../locators/CheckBoxLocators');
class CheckBoxPage extends BasePage{
    async open(){
        await this.goto('/checkbox')
    }
    async selectHome(){
        await this.click(L.home)
    }
    async result(){
        return this.text(L.result)
    }
}
module.exports = { CheckBoxPage };
