class BasePage {
    constructor(page) {
        this.page = page
    }
    async goto(path = '/') {
        await this.page.goto(path, { waitUntil: 'commit' });
        await this.page.waitForLoadState('domcontentloaded', { timeout: 10000 }).catch(() => {})
    }
    async click(s) {
        await this.page.locator(s).click()
    }
    async fill(s, v) {
        await this.page.locator(s).fill(String(v))
    }
    async text(s) {
        return (await this.page.locator(s).first().innerText()).trim()
    }
    async value(s) {
        return this.page.locator(s).inputValue()
    }
}
module.exports = { BasePage };
