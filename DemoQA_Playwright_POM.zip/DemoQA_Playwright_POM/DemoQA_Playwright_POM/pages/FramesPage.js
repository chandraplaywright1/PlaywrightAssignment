const { BasePage } = require('./BasePage');
const { FramesLocators: L } = require('../locators/FramesLocators');

class FramesPage extends BasePage {
    async open() {
        await this.goto('/frames')

    }
    async heading(frame) {
        return this.page.frameLocator(frame === 1 ? L.one : L.two).locator('h1').innerText()
    }
}
module.exports = { FramesPage };
