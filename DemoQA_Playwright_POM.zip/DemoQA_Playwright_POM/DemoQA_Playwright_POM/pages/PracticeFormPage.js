const { BasePage } = require('./BasePage');
const { PracticeFormLocators: L } = require('../locators/PracticeFormLocators');

class PracticeFormPage extends BasePage {
    async open() {
        await this.goto('/automation-practice-form')
    }
    async fillForm(d) {
        for (const [s, v] of [[L.first, d.firstName], [L.last, d.lastName], [L.email, d.email], [L.mobile, d.mobile], [L.subject, d.subject], [L.address, d.address]]) {
            await this.fill(s, v)
        }
        await this.click(L.male)
        await this.click(L.sport)
    }
    async submit() {
        await this.click(L.submit)
    }
}
module.exports = { PracticeFormPage };
