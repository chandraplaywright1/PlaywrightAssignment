const { BasePage } = require('./BasePage');
const { WebTablesLocators: L } = require('../locators/WebTablesLocators');

class WebTablesPage extends BasePage {
    async open() {
        await this.goto('/webtables')
    }
    async add(d) {
        await this.click(L.add);
        for (const [s, v] of [[L.first, d.firstName], [L.last, d.lastName], [L.email, d.email], [L.age, d.age], [L.salary, d.salary], [L.dept, d.department]]) await this.fill(s, v);
        await this.click(L.submit)
    }
    async search(v) {
        await this.fill(L.search, v)
    }
}
module.exports = { WebTablesPage };
