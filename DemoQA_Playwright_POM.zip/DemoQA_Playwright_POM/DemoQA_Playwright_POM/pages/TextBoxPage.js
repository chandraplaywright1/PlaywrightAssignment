const { BasePage } = require('./BasePage');
const { TextBoxLocators: L } = require('../locators/TextBoxLocators');

class TextBoxPage extends BasePage {
    async open() {
        await this.goto('/text-box')
    }
    async enter(d) {
        await this.fill(L.name, d.fullName);
        await this.fill(L.email, d.email);
        await this.fill(L.current, d.currentAddress);
        await this.fill(L.permanent, d.permanentAddress);
        await this.click(L.submit)
    }
}
module.exports = { TextBoxPage };
