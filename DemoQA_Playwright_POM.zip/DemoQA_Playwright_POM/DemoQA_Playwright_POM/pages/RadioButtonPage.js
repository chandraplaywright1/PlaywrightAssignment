const { BasePage } = require('./BasePage');
const { RadioButtonLocators: L } = require('../locators/RadioButtonLocators');

class RadioButtonPage extends BasePage {
    async open() {
        this.page.on('dialog', dialog => dialog.dismiss());
        await this.goto('/radio-button')
    }
    async yes() {
        const yes = this.page.locator(L.yes);
        await yes.scrollIntoViewIfNeeded();
        await yes.click({ timeout: 10000 });
    }
    async impressive() {
        await this.click(L.impressive)
    }
    async result() {
        return this.text(L.result)
    }
    async noDisabled() {
        return this.page.locator(L.no).isDisabled()
    }
}
module.exports = { RadioButtonPage };
