const { BasePage } = require('./BasePage');
const { AlertsLocators: L } = require('../locators/AlertsLocators');

class AlertsPage extends BasePage {
    async open() {
        await this.goto('/alerts')
    }
    async alert() {
        const p = this.page.waitForEvent('dialog');
        p.then(dialog => dialog.accept());
        await this.click(L.alert);
        const d = await p;
        return d.message()
    }
    async confirm() {
        const p = this.page.waitForEvent('dialog');
        p.then(dialog => dialog.accept());
        await this.click(L.confirm);
        const d = await p;
        return d.message()
    }
    async prompt(v) {
        const p = this.page.waitForEvent('dialog');
        p.then(dialog => dialog.accept(v));
        await this.click(L.prompt);
        const d = await p;
        return d.message()
    }
}
module.exports = { AlertsPage };
