const { BasePage } = require('./BasePage');
const { DatePickerLocators: L } = require('../locators/DatePickerLocators');

class DatePickerPage extends BasePage {
    async open() {
        await this.goto('/date-picker')
    }
    async setDate(v) {
        await this.fill(L.input, v);
        await this.page.keyboard.press('Enter')
    }
    async value() {
        return this.value(L.input)
    }
}
module.exports = { DatePickerPage };
