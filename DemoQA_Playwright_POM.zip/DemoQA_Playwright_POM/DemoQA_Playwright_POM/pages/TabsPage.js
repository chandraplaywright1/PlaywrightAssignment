const { BasePage } = require('./BasePage');
const { TabsLocators: L } = require('../locators/TabsLocators');

class TabsPage extends BasePage {
    async open() {
        await this.goto('/tabs')
    }
    async profile() {
        await this.click(L.profile)
    }
    async contact() {
        await this.click(L.contact)
    }
    async content() {
        return this.text(L.content)
    }
}
module.exports = { TabsPage };
