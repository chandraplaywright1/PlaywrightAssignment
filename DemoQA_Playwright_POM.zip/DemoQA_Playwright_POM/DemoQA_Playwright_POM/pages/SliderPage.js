const { BasePage } = require('./BasePage');
const { SliderLocators: L } = require('../locators/SliderLocators');

class SliderPage extends BasePage {
    async open() {
        await this.goto('/slider')
    }
    async set(v) {
        await this.page.locator(L.slider).fill(String(v))
    }
    async value() {
        return this.page.locator(L.slider).inputValue()
    }
}
module.exports = { SliderPage };
