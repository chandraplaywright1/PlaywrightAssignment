module.exports = {
    PracticeFormLocators: {
        first: '#firstName',
        last: '#lastName',
        email: '#userEmail',
        male: 'label[for="gender-radio-1"]',
        mobile: '#userNumber',
        subject: '#subjectsInput',
        sport: 'label[for="hobbies-checkbox-1"]',
        address: '#currentAddress',
        submit: '#submit',
        modal: '.modal-content'
    }
};
