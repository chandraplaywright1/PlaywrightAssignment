module.exports = {
  AlertsLocators: {
    alert: '#alertButton',
    confirm: '#confirmButton',
    prompt: '#promtButton',
    confirmResult: '#confirmResult',
    promptResult: '#promptResult',
  },
};