module.exports = {
    TextBoxLocators: {
        name: '#userName',
        email: '#userEmail',
        current: '#currentAddress',
        permanent: '#permanentAddress',
        submit: '#submit',
        output: '#output'
    }
};
