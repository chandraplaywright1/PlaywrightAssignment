module.exports = {
    FramesLocators: {
        one: '#frame1',
        two: '#frame2'
    }
};
