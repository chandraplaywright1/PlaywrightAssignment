module.exports = {
    SliderLocators: {
        slider: 'input[type="range"]'
    }
};
