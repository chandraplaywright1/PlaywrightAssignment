module.exports = {
    DatePickerLocators: {
        input: '#datePickerMonthYearInput'
    }
};
