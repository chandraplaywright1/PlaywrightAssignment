module.exports = {
    RadioButtonLocators: {
        yes: 'label[for="yesRadio"]',
        impressive: 'label[for="impressiveRadio"]',
        no: '#noRadio',
        result: '.text-success'
    }
};
