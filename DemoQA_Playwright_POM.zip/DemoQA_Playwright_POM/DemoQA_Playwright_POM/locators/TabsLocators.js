module.exports = {
    TabsLocators: {
            profile: '[role="tab"][aria-controls="demo-tabpane-origin"]',
            contact: '[role="tab"][aria-controls="demo-tabpane-use"]',
        content: '.tab-content'
    }
};
