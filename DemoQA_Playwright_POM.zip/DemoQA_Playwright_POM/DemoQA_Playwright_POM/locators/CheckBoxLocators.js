module.exports = {
  CheckBoxLocators: {
    home: '[role="checkbox"][aria-label="Select Home"]',
    result: '#result'
  }
};
