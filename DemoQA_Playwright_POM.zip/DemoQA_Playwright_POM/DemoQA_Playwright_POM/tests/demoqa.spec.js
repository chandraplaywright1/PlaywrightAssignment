const { expect } = require('@playwright/test');
const { test } = require('../hooks/testHooks');
const d = require('../testData/demoqaData.json');

test('TC01 Text Box', async ({ textBoxPage }) => {
    await textBoxPage.open(); await textBoxPage.enter(d.textBox);
    await expect(textBoxPage.page.locator('#output')).toContainText(d.textBox.fullName)
});

test('TC02 Check Box', async ({ checkBoxPage }) => {
    await checkBoxPage.open();
    await checkBoxPage.selectHome();
    await expect(checkBoxPage.page.locator('#result')).toContainText('home')
});

test('TC03 Radio Buttons', async ({ radioButtonPage }) => {
    await radioButtonPage.open();
    await radioButtonPage.yes();
    await expect(radioButtonPage.page.locator('.text-success')).toContainText('Yes');
    expect(await radioButtonPage.noDisabled()).toBeTruthy()
});

test('TC04 Web Tables', async ({ webTablesPage }) => {
    await webTablesPage.open();
    await webTablesPage.add(d.webTable);
    await webTablesPage.search(d.webTable.firstName);
    await expect(webTablesPage.page.locator('table')).toContainText(d.webTable.firstName)
});

test('TC05 Practice Form', async ({ practiceFormPage }) => {
    await practiceFormPage.open();
    await practiceFormPage.fillForm(d.form);
    await practiceFormPage.submit();
    await expect(practiceFormPage.page.getByRole('dialog')).toContainText(d.form.firstName)
});

test('TC06 Alerts', async ({ alertsPage }) => {
    await alertsPage.open();
    expect(await alertsPage.alert()).toContain('You clicked a button');
    expect(await alertsPage.confirm()).toContain('Do you confirm action?');
    expect(await alertsPage.prompt(d.alerts.prompt)).toContain('Please enter your name');
    await expect(alertsPage.page.locator('#promptResult')).toContainText(d.alerts.prompt)
});

test('TC07 Frames', async ({ framesPage }) => {
    await framesPage.open();
    await expect(framesPage.heading(1)).resolves.toContain('This is a sample page');
    await expect(framesPage.heading(2)).resolves.toContain('This is a sample page')
});

test('TC08 Date Picker', async ({ datePickerPage }) => {
    await datePickerPage.open();
    await datePickerPage.setDate(d.date);
    await expect(datePickerPage.page.locator('#datePickerMonthYearInput')).toHaveValue(d.date)
});

test('TC09 Slider', async ({ sliderPage }) => {
    await sliderPage.open();
    await sliderPage.set(d.slider);
    await expect(sliderPage.page.locator('input[type="range"]')).toHaveValue(d.slider)
});

test('TC10 Tabs', async ({ tabsPage }) => {
    await tabsPage.open();
    await tabsPage.profile();
    await expect(tabsPage.page.getByRole('tabpanel')).toContainText('Lorem Ipsum');
    await tabsPage.contact();
    await expect(tabsPage.page.getByRole('tabpanel')).toContainText('long established')
});
