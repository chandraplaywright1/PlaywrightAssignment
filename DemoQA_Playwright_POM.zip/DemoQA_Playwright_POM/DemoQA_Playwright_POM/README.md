# DemoQA Playwright JavaScript POM Framework

Target: https://demoqa.com/

## Coverage
- Text Box
- Check Box
- Radio Buttons
- Web Tables
- Practice Form
- JavaScript Alerts
- Frames
- Date Picker
- Slider
- Tabs

## Structure
- `locators/` - selectors only
- `pages/` - separate Page Object classes
- `pages/BasePage.js` - reusable Playwright actions
- `hooks/testHooks.js` - custom Playwright fixtures
- `testData/demoqaData.json` - external test data
- `tests/demoqa.spec.js` - test scenarios

## Install
```bash
npm install
npx playwright install chromium
```

## Run
```bash
npm test
npm run test:headed
npm run test:debug
npm run test:ui
npm run report
```

To add a new DemoQA component, create its locator class, page class, register it in the hooks, add JSON data when needed, and add a test.
