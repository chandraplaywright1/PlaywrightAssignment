class InfiniteScrollLocators { 
    static paragraphs='.jscroll-added'; 
    static body='body'; 
}
module.exports={InfiniteScrollLocators};
