class LoginLocators { 
    static username='#username'; 
    static password='#password'; 
    static loginButton='button[type="submit"]'; 
    static flashMessage='#flash'; 
    static logoutButton='a[href="/logout"]'; 
}
module.exports={LoginLocators};
