class HoverLocators { 
    static figure='.figure'; 
    static caption='.figcaption'; 
}
module.exports={HoverLocators};
