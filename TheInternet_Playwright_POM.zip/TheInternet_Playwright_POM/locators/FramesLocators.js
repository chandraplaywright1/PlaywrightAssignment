class FramesLocators { 
    static frame='#mce_0_ifr'; 
    static editorBody='body#tinymce'; 
}
module.exports={FramesLocators};
