class DragDropLocators { 
    static columnA='#column-a'; 
    static columnB='#column-b'; 
    static headerA='#column-a header'; 
    static headerB='#column-b header'; 
}
module.exports={DragDropLocators};
