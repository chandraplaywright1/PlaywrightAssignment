class ShadowDomLocators { 
    static host='my-paragraph'; 
    static paragraph='my-paragraph p'; 
}
module.exports={ShadowDomLocators};
