class DynamicLoadingLocators { 
    static startButton='#start button'; 
    static finish='#finish'; 
    static finishText='#finish h4'; 
}
module.exports={DynamicLoadingLocators};
