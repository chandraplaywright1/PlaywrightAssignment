class AlertsLocators { 
    static jsAlert='button[onclick="jsAlert()"]'; 
    static jsConfirm='button[onclick="jsConfirm()"]'; 
    static jsPrompt='button[onclick="jsPrompt()"]'; 
    static result='#result'; 
}
module.exports={AlertsLocators};
