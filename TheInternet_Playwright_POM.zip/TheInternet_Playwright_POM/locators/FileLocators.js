class FileLocators { 
    static fileInput='#file-upload'; 
    static uploadButton='#file-submit'; 
    static uploadedFiles='#uploaded-files'; 
    static downloadLinks='#content a'; 
}
module.exports={FileLocators};
