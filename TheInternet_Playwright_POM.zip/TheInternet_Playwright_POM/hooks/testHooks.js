const { test: base } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');
const { DynamicLoadingPage } = require('../pages/DynamicLoadingPage');
const { AlertsPage } = require('../pages/AlertsPage');
const { HoverPage } = require('../pages/HoverPage');
const { FilePage } = require('../pages/FilePage');
const { FramesPage } = require('../pages/FramesPage');
const { DragDropPage } = require('../pages/DragDropPage');
const { InfiniteScrollPage } = require('../pages/InfiniteScrollPage');
const { ShadowDomPage } = require('../pages/ShadowDomPage');
const test = base.extend({
    loginPage: async ({ page }, use) => use(new LoginPage(page)), dynamicLoadingPage: async ({ page }, use) => use(new DynamicLoadingPage(page)), alertsPage: async ({ page }, use) => use(new AlertsPage(page)), hoverPage: async ({ page }, use) => use(new HoverPage(page)), filePage: async ({ page }, use) => use(new FilePage(page)), framesPage: async ({ page }, use) => use(new FramesPage(page)), dragDropPage: async ({ page }, use) => use(new DragDropPage(page)), infiniteScrollPage: async ({ page }, use) => use(new InfiniteScrollPage(page)), shadowDomPage: async ({ page }, use) => use(new ShadowDomPage(page))
});
module.exports = { test };
