const { expect } = require('@playwright/test');
const path = require('path');
const { test } = require('../hooks/testHooks');
const data = require('../testData/challengeData.json');

test.describe('The Internet - Playwright POM Challenge Suite', () => {
    test('TC01 - Form authentication valid login', async ({ loginPage }) => {
        await loginPage.open();
        await loginPage.login(data.login.validUsername, data.login.validPassword);
        await expect(loginPage.page).toHaveURL(/secure/);
        await expect(loginPage.getFlashMessage()).resolves.toContain('You logged into a secure area!');
    });

    test('TC02 - Form authentication invalid login', async ({ loginPage }) => {
        await loginPage.open();
        await loginPage.login(data.login.invalidUsername, data.login.invalidPassword);
        await expect(loginPage.page).toHaveURL(/login/);
        await expect(loginPage.getFlashMessage()).resolves.toContain('Your username is invalid!');
    });

    test('TC03 - Dynamic Loading example 2', async ({ dynamicLoadingPage }) => {
        await dynamicLoadingPage.open();
        await dynamicLoadingPage.start();
        await dynamicLoadingPage.waitForFinish();
        await expect(dynamicLoadingPage.getFinishText()).resolves.toBe(data.dynamicLoading.expectedText);
    });

    test('TC04 - JavaScript alerts confirm prompt', async ({ alertsPage }) => {
        await alertsPage.open();
        expect(await alertsPage.acceptAlert()).toContain('I am a JS Alert');
        await expect(alertsPage.getResult()).resolves.toContain('You successfully clicked an alert');
        expect(await alertsPage.dismissConfirm()).toContain('I am a JS Confirm');
        await expect(alertsPage.getResult()).resolves.toContain('You clicked: Cancel');
        expect(await alertsPage.answerPrompt(data.alerts.promptText)).toContain('I am a JS prompt');
        await expect(alertsPage.getResult()).resolves.toContain(data.alerts.promptText);
    });

    test('TC05 - Hover', async ({ hoverPage }) => {
        await hoverPage.open(); await hoverPage.hover(0);
        await expect(hoverPage.page.locator('.figure').nth(0).locator('.figcaption')).toBeVisible();
    });

    test('TC06 - File upload', async ({ filePage }) => {
        await filePage.openUpload();
        await filePage.upload(path.resolve(__dirname, '../testData/sample-upload.txt'));
        await expect(filePage.uploadedName()).resolves.toBe('sample-upload.txt');
    });

    test('TC07 - File download', async ({ filePage }) => {
        await filePage.openDownload();
        const download = await filePage.downloadFirst();
        expect(await download.suggestedFilename()).toBeTruthy();
    });

    test('TC08 - IFrame editor', async ({ framesPage }) => {
        await framesPage.open(); await framesPage.fillEditor(data.iframe.editorText);
        await expect(framesPage.getEditorText()).resolves.toContain(data.iframe.editorText);
    });

    test('TC09 - Drag and drop', async ({ dragDropPage }) => {
        await dragDropPage.open();
        const a = await dragDropPage.headerA();
        const b = await dragDropPage.headerB();
        await dragDropPage.dragAtoB();
        expect(await dragDropPage.headerA()).toBe(b);
        expect(await dragDropPage.headerB()).toBe(a);
    });

    test('TC10 - Infinite scroll', async ({ infiniteScrollPage }) => {
        await infiniteScrollPage.open();
        const before = await infiniteScrollPage.paragraphCount();
        await infiniteScrollPage.scroll(data.infiniteScroll.scrollTimes);
        expect(await infiniteScrollPage.paragraphCount()).toBeGreaterThan(before);
    });

    test('TC11 - Shadow DOM', async ({ shadowDomPage }) => {
        await shadowDomPage.open();
        expect(await shadowDomPage.hostCount()).toBeGreaterThan(0);
        await expect(shadowDomPage.text()).resolves.toContain('My default text');
    });

});
