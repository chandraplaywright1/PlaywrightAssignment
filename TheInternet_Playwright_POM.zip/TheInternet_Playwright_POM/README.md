# The Internet - Playwright JavaScript POM Framework

Target: https://the-internet.herokuapp.com/

Representative challenge coverage: Form Authentication, Dynamic Loading, JavaScript Alerts/Confirm/Prompt, Hovers, File Upload, File Download, IFrame, Drag and Drop, Infinite Scroll and Shadow DOM.

## Structure

- `locators/` - selectors only
- `pages/` - page objects and business actions
- `BasePage.js` - reusable browser methods
- `hooks/testHooks.js` - custom Playwright fixtures
- `testData/` - JSON data and upload fixture
- `tests/` - scenarios and assertions

## Install

```bash
npm install
npx playwright install chromium
```

## Run

```bash
npm test
npm run test:headed
npm run test:debug
npm run test:ui
npm run report
```

## Add another challenge

Create a locator class, create a page class extending `BasePage`, register it in `hooks/testHooks.js`, add test data if needed, then add the scenario under `tests/`.
