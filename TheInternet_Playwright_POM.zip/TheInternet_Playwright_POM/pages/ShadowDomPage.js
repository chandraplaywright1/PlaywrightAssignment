const {BasePage}=require('./BasePage'); 
const {ShadowDomLocators}=require('../locators/ShadowDomLocators');

class ShadowDomPage extends BasePage { 
    async open(){
        await this.goto('/shadowdom');
    } 
    async text(){
        return this.page.locator(ShadowDomLocators.host).first().evaluate((element) => {
            if (!element.shadowRoot) return '';
            return element.shadowRoot.textContent.trim();
        });
    } 
    async hostCount(){
        return this.count(ShadowDomLocators.host);
    } 
}
module.exports={ShadowDomPage};
