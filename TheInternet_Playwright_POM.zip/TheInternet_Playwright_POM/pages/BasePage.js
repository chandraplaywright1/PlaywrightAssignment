class BasePage {
     constructor(page){
        this.page=page;
    } 
    async goto(path='/'){
        await this.page.goto(path);
        await this.page.waitForLoadState('domcontentloaded');
    } 
    async click(locator){
        await this.page.locator(locator).click();
    } 
    async fill(locator,value){
        await this.page.locator(locator).fill(String(value));
    } 
    async getText(locator){
        return (await this.page.locator(locator).first().innerText()).trim();
    } 
    async count(locator){
        return this.page.locator(locator).count();
    } 
    async waitForVisible(locator){
        await this.page.locator(locator).first().waitFor({state:'visible'});
    } 
}
module.exports={BasePage};
