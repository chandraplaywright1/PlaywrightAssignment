const {BasePage}=require('./BasePage'); 
const {DragDropLocators}=require('../locators/DragDropLocators');
class DragDropPage extends BasePage { 
    async open(){await this.goto('/drag_and_drop');

    } 
    async dragAtoB(){
        await this.page.locator(DragDropLocators.columnA).dragTo(this.page.locator(DragDropLocators.columnB));
    } 
    async headerA(){
        return this.getText(DragDropLocators.headerA);
    } 
    async headerB(){
        return this.getText(DragDropLocators.headerB);
    } 
}
module.exports={DragDropPage};
