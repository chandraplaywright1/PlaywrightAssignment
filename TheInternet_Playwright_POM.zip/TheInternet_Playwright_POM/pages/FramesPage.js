const { BasePage } = require('./BasePage');
const { FramesLocators } = require('../locators/FramesLocators');

class FramesPage extends BasePage {

    async open() {
        await this.goto('/iframe');
    }

    async fillEditor(text) {
        const editor = this.page.frameLocator(FramesLocators.frame).locator('body');
        await editor.evaluate((node, value) => {
            node.setAttribute('contenteditable', 'true');
            node.textContent = value;
        }, text);
    }
    
    async getEditorText() {
        return this.page.frameLocator(FramesLocators.frame).locator('body').innerText();
    }
}
module.exports = { FramesPage };
