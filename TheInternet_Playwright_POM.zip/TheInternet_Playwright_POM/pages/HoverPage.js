const {BasePage}=require('./BasePage'); 
const {HoverLocators}=require('../locators/HoverLocators');

class HoverPage extends BasePage { 
    async open(){await this.goto('/hovers');

    } 
    
    async hover(index=0){
        await this.page.locator(HoverLocators.figure).nth(index).hover();
    } 
    
    async caption(index=0){
        return this.page.locator(HoverLocators.figure).nth(index).locator(HoverLocators.caption).innerText();
    } 
}
module.exports={HoverPage};
