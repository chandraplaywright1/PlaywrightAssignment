const {BasePage}=require('./BasePage'); 
const {InfiniteScrollLocators}=require('../locators/InfiniteScrollLocators');
class InfiniteScrollPage extends BasePage { 
    async open(){
        await this.goto('/infinite_scroll');
    } 
    async scroll(times=3){
        for(let i=0;i<times;i++){
            await this.page.locator(InfiniteScrollLocators.body).evaluate(()=>window.scrollTo(0,document.body.scrollHeight));
            await this.page.waitForTimeout(300);
        }
    } 
    async paragraphCount(){
        return this.count(InfiniteScrollLocators.paragraphs);
    } 
}
module.exports={InfiniteScrollPage};
