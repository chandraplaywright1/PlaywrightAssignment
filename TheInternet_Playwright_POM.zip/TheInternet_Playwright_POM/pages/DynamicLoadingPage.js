const {BasePage}=require('./BasePage'); 
const {DynamicLoadingLocators}=require('../locators/DynamicLoadingLocators');

class DynamicLoadingPage extends BasePage { 
    async open(){
        await this.goto('/dynamic_loading/2');
    } 
    async start(){
        await this.click(DynamicLoadingLocators.startButton);
    } 
    async waitForFinish(){
        await this.page.locator(DynamicLoadingLocators.finish).waitFor({state:'visible'});
    } 
    async getFinishText(){
        return this.getText(DynamicLoadingLocators.finishText);
    } 
}
module.exports={DynamicLoadingPage};
