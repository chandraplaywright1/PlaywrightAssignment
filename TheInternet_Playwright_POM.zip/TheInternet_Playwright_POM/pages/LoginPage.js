const {BasePage}=require('./BasePage'); 
const {LoginLocators}=require('../locators/LoginLocators');
class LoginPage extends BasePage { 
    async open(){
        await this.goto('/login');
    } 
    async login(username,password){
        await this.fill(LoginLocators.username,username);
        await this.fill(LoginLocators.password,password);
        await this.click(LoginLocators.loginButton);
    } 
    async getFlashMessage(){
        return this.getText(LoginLocators.flashMessage);
    } 
}
module.exports={LoginPage};
