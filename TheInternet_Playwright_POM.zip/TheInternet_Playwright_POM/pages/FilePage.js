const {BasePage}=require('./BasePage'); 
const {FileLocators}=require('../locators/FileLocators');

class FilePage extends BasePage { 
    async openUpload(){
        await this.goto('/upload');
    } 
    async upload(filePath){
        await this.page.locator(FileLocators.fileInput).setInputFiles(filePath);
        await this.click(FileLocators.uploadButton);
    } 
    async uploadedName(){
        return this.getText(FileLocators.uploadedFiles);
    } 
    async openDownload(){
        await this.goto('/download');
    } 
    async downloadFirst(){
        const p=this.page.waitForEvent('download');
        await this.page.locator(FileLocators.downloadLinks).first().click();
        return p;
    } 
}
module.exports={FilePage};
