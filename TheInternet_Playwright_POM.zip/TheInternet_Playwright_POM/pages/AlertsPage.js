const { BasePage } = require('./BasePage');
const { AlertsLocators } = require('../locators/AlertsLocators');

class AlertsPage extends BasePage {
    async open() {
        await this.goto('/javascript_alerts');

    }
    async acceptAlert() {
        let dialogMessage = '';
        this.page.once('dialog', async (dialog) => {
            dialogMessage = dialog.message();
            await dialog.accept();
        });
        await this.page.locator(AlertsLocators.jsAlert).click();
        return dialogMessage;
    }
    async dismissConfirm() {
        let dialogMessage = '';
        this.page.once('dialog', async (dialog) => {
            dialogMessage = dialog.message();
            await dialog.dismiss();
        });
        await this.page.locator(AlertsLocators.jsConfirm).click();
        return dialogMessage;
    }
    async answerPrompt(value) {
        let dialogMessage = '';
        this.page.once('dialog', async (dialog) => {
            dialogMessage = dialog.message();
            await dialog.accept(value);
        });
        await this.page.locator(AlertsLocators.jsPrompt).click();
        return dialogMessage;
    }
    async getResult() {
        return this.getText(AlertsLocators.result);
    }
}
module.exports = { AlertsPage };
