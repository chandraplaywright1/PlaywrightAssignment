const { test: base } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');
const { RegisterPage } = require('../pages/RegisterPage');
const { PracticeFormPage } = require('../pages/PracticeFormPage');
const test = base.extend({
  loginPage: async ({ page }, use) => await use(new LoginPage(page)),
  registerPage: async ({ page }, use) => await use(new RegisterPage(page)),
  practiceFormPage: async ({ page }, use) => await use(new PracticeFormPage(page)),
});
module.exports = { test, expect: base.expect };
