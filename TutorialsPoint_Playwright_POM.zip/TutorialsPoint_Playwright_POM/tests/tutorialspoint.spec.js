const { test, expect } = require('../hooks/testHooks');
const data = require('../testData/testData.json');

test.describe('TutorialsPoint Selenium Practice - POM', () => {
  test('TC01 - Verify Login page and navigate to Register page', async ({ loginPage, registerPage }) => {
    await loginPage.open();
    await expect(loginPage.page).toHaveURL(/login\.php/);
    await expect(loginPage.page.locator('#signInForm h1')).toContainText('Welcome');
    await loginPage.openRegister();
    await expect(registerPage.page).toHaveURL(/register\.php/);
    await expect(registerPage.page.locator('#signupForm h1')).toContainText('Register');
  });

  test('TC02 - Validate login with invalid credentials', async ({ loginPage }) => {
    await loginPage.open();
    await loginPage.login(data.login.username, data.login.password);
    await expect(loginPage.page).toHaveURL(/login\.php/);
  });

  test('TC03 - Verify Register page fields', async ({ loginPage, registerPage }) => {
    await loginPage.open();
    await loginPage.openRegister();
    await expect(registerPage.page.locator('#signupForm #firstname')).toBeVisible();
    await expect(registerPage.page.locator('#signupForm #lastname')).toBeVisible();
    await expect(registerPage.page.locator('#signupForm #username')).toBeVisible();
    await expect(registerPage.page.locator('#signupForm #password')).toBeVisible();
  });

  test('TC04 - Fill Practice Form', async ({ practiceFormPage }) => {
    await practiceFormPage.open();
    await practiceFormPage.fillForm(data.practiceForm);
    await expect(practiceFormPage.page.locator('#name')).toHaveValue(`${data.practiceForm.firstName} ${data.practiceForm.lastName}`);
    await expect(practiceFormPage.page.locator('#email')).toHaveValue(data.practiceForm.email);
    await expect(practiceFormPage.page.locator('#mobile')).toHaveValue(data.practiceForm.mobile);
  });
});
