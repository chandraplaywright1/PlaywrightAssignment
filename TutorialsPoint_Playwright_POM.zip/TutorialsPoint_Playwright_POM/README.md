# TutorialsPoint Playwright JavaScript POM Framework

Target: https://www.tutorialspoint.com/selenium/practice/

## Architecture
- `locators/` - centralized selectors only
- `pages/` - separate Page Object classes and reusable BasePage
- `hooks/` - Playwright custom fixtures
- `testData/` - external JSON test data
- `tests/` - assertions and test scenarios

## Install
```bash
npm install
npx playwright install chromium
```

## Run
```bash
npm test
npm run test:headed
npm run test:ui
npm run test:debug
npm run report
```

## Scenarios
1. Login page validation and Register navigation
2. Invalid login validation
3. Register page field validation
4. Practice form data entry

## POM rule
Keep selectors in `locators/`, browser interactions in `pages/`, assertions in `tests/`, and reusable test data in JSON.
