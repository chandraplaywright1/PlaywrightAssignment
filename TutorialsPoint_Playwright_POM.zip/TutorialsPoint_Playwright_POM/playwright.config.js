const { defineConfig } = require('@playwright/test');
module.exports = defineConfig({
  testDir: './tests', timeout: 30000, expect: { timeout: 5000 },
  fullyParallel: false, workers: 1,
  use: { baseURL: 'https://www.tutorialspoint.com/selenium/practice/', headless: true, screenshot: 'only-on-failure', video: 'retain-on-failure', trace: 'retain-on-failure' },
  reporter: [['list'], ['html', { open: 'never' }]],
});
