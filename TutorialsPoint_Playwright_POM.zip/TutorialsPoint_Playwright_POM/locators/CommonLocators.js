module.exports = {
    homeLink: 'a[href="index.php"]'
};
