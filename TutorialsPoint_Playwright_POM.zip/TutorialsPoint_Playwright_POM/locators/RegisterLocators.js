module.exports = { 
    heading: '#signupForm h1', 
    firstName: '#firstname', 
    lastName: '#lastname', 
    username: '#username', 
    password: '#password', 
    registerButton: 'input[type="submit"]' 
};
