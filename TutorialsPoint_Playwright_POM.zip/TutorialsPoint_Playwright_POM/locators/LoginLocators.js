module.exports = {
    heading: '#signInForm h1',
    username: '#email',
    password: '#password',
    loginButton: 'input[type="submit"]',
    newUserLink: '#signInForm a[href="register.php"]'
};
