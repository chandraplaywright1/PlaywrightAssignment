module.exports = {
    name: '#name',
    genderMale: '#gender',
    genderFemale: '#female',
    email: '#email',
    mobile: '#mobile',
    dob: '#dob',
    subjects: '#subjects',
    address: 'textarea[placeholder="Currend Address"]',
    submit: 'input[type="submit"]'
};
