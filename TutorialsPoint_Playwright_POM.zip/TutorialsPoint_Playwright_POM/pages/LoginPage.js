const { BasePage } = require('./BasePage');
const L = require('../locators/LoginLocators');
class LoginPage extends BasePage {
  async open() {
    await this.goto('login.php');
  }
  async login(username, password) {
    await this.fill(L.username, username);
    await this.fill(L.password, password);
    await this.click(L.loginButton);
  }
  async openRegister() {
    await this.click(L.newUserLink);
  }
  async heading() {
    return this.text(L.heading);
  }
}
module.exports = { LoginPage };
