class BasePage {
  constructor(page) {
    this.page = page;
  }

  async goto(path = '') {
    await this.page.goto(path);
  }
  async click(selector) {
    await this.page.locator(selector).click();
  }

  async fill(selector, value) {
    await this.page.locator(selector).fill(value);
  }

  async text(selector) {
    return this.page.locator(selector).innerText();
  }

  async value(selector) {
    return this.page.locator(selector).inputValue();
  }

  async waitForURL(url) {
    await this.page.waitForURL(url);
  }
}
module.exports = { BasePage };
