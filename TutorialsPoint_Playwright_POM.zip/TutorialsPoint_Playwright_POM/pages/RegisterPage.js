const { BasePage } = require('./BasePage');
const L = require('../locators/RegisterLocators');
class RegisterPage extends BasePage {
  async heading() {
    return this.text(L.heading);
  }

  async register(data) { await this.fill(L.firstName, data.firstName); await this.fill(L.lastName, data.lastName); await this.fill(L.username, data.username); await this.fill(L.password, data.password); await this.click(L.registerButton); }
}
module.exports = { RegisterPage };
