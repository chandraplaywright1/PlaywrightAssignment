const { BasePage } = require('./BasePage');
const L = require('../locators/PracticeFormLocators');
class PracticeFormPage extends BasePage {
  async open() {
    await this.goto('selenium_automation_practice.php');
  }
  async fillForm(data) {
    await this.fill(L.name, `${data.firstName} ${data.lastName}`);
    await this.click(data.gender === 'Female' ? L.genderFemale : L.genderMale);
    await this.fill(L.email, data.email);
    await this.fill(L.mobile, data.mobile);
    await this.fill(L.dob, data.dob);
    await this.fill(L.subjects, data.subjects);
    await this.fill(L.address, data.address);
  }
  async submit() {
    await this.click(L.submit);
  }
}
module.exports = { PracticeFormPage };
