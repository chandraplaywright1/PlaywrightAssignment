module.exports = {
  signupLink: '#signin2',
  loginLink: '#login2',
  welcomeUser: '#nameofuser',
  cartLink: '#cartur',
  allproduct: '#tbodyid'
};