module.exports = {
  username: '#loginusername',
  password: '#loginpassword',
  loginBtn: 'button[onclick="logIn()"]',
  loggedUser: '#nameofuser',
  logindialog: '#logInModal'
};