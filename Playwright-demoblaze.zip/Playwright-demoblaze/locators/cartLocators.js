module.exports = {
  cartRows: '#tbodyid tr',
  placeOrderBtn: 'button.btn.btn-success',
  product: '#tbodyid'
};