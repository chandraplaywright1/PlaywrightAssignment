module.exports = {
  name: '#name',
  country: '#country',
  city: '#city',
  creditCard: '#card',
  month: '#month',
  year: '#year',
  purchaseBtn: 'button[onclick="purchaseOrder()"]',
  successMessage: '.sweet-alert h2',
  okButton: '.confirm',
  placeorderdialog: '#orderModal'
};