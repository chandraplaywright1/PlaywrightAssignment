module.exports = {
  username: '#sign-username',
  password: '#sign-password',
  signupBtn: 'button[onclick="register()"]',
  signupDialog: '#signInModal'
};