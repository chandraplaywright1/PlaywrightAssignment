module.exports = {
  productTitle: '.hrefch',
  addToCartBtn: 'a.btn.btn-success.btn-lg',
  productName: '.name'
};