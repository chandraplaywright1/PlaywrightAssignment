module.exports = {

    username: `user_${Date.now()}`,

    password: "Test@123",

    productName: "Samsung galaxy s6",

    orderDetails: {
        name: "Chandra",
        country: "India",
        city: "Bangalore",
        card: "1600000000000000",
        month: "09",
        year: "2029"
    }
};