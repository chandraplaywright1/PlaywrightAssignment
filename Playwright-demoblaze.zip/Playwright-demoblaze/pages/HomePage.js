const { expect } = require('@playwright/test');
const homeLocators = require('../locators/homeLocators');

class HomePage {

    constructor(page) {
        this.page = page;
    }

    async navigate() {

        await this.page.goto(
            'https://www.demoblaze.com/',
            {
                waitUntil: 'domcontentloaded'
            }
        );

        await expect(
            this.page.locator(homeLocators.allproduct)
        ).toBeVisible({
            timeout: 15000
        });
    }

    async clickSignup() {

        await this.page.locator(homeLocators.signupLink).click();
    }

    async clickLogin() {

        await this.page.locator(homeLocators.loginLink).click();
    }

    async openCart() {

        await this.page.locator(homeLocators.cartLink).click();
    }
}

module.exports = HomePage;