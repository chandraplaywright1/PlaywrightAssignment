const { expect } = require('@playwright/test');
const locators = require('../locators/placeOrderLocators');
const placeOrderLocators = require('../locators/placeOrderLocators');

class PlaceOrderPage {

    constructor(page) {
        this.page = page;
    }

    async placeOrder(orderData) {

        // Wait for Order Modal
        await expect(
            this.page.locator(placeOrderLocators.placeorderdialog)
        ).toBeVisible({
            timeout: 10000
        });

        await this.page.fill(locators.name,orderData.name);

        await this.page.fill(locators.country, orderData.country);

        await this.page.fill(locators.city,orderData.city);

        await this.page.fill(locators.creditCard, orderData.card);

        await this.page.fill(locators.month, orderData.month);

        await this.page.fill(locators.year, orderData.year);

        await this.page.click(locators.purchaseBtn);
    }

    async verifyOrderSuccess() {

        await expect(this.page.locator(locators.successMessage)
        ).toBeVisible({
            timeout: 15000
        });

        await expect(this.page.locator(locators.successMessage)
        ).toContainText('Thank you for your purchase!');

        await this.page.click(locators.okButton);
    }
}

module.exports = PlaceOrderPage;