const { expect } = require('@playwright/test');
const loginLocators = require('../locators/loginLocators');

class LoginPage {

    constructor(page) {
        this.page = page;
    }

    async login(username, password) {

        await expect(
            this.page.locator(loginLocators.logindialog)
        ).toBeVisible({
            timeout: 10000
        });

        await this.page.fill(loginLocators.username , username);

        await this.page.fill(loginLocators.password , password);

        let loginError = '';

        this.page.once('dialog', async dialog => {

            loginError = dialog.message();

            console.log(
                'LOGIN ERROR:',
                loginError
            );

            await dialog.accept();
        });

        await this.page.click(loginLocators.loginBtn);

        await this.page.waitForTimeout(5000);

        if (loginError) {
            throw new Error(
                `Login Failed: ${loginError}`
            );
        }

        await expect(this.page.locator(loginLocators.loggedUser)
        ).toContainText(
            'Welcome',
            {
                timeout: 10000
            }
        );

        console.log(`Login Successful : ${username}`);
    }
}

module.exports = LoginPage;