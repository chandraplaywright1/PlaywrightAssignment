const { expect } = require('@playwright/test');
const cartLocators = require('../locators/cartLocators');


class CartPage {

    constructor(page) {
        this.page = page;
    }

    async verifyProduct(productName) {

        // Wait for cart table to load
      
       await this.page.locator(cartLocators.cartRows)
            .first()
            .waitFor({
                state: 'visible',
                timeout: 15000
            });

        // Verify product exists in cart
        await expect(
            this.page.locator(cartLocators.product)
        ).toContainText(productName);
    }

    async clickPlaceOrder() {

        // Wait for Place Order button
        await expect(
            this.page.locator(cartLocators.placeOrderBtn)
        ).toBeVisible();

        await this.page.locator(cartLocators.placeOrderBtn).click();
    }
}

module.exports = CartPage;