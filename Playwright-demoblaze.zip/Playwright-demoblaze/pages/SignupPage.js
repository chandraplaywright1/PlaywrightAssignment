const { expect } = require('@playwright/test');
const signuplocators = require('../locators/signupLocators');

class SignupPage {

    constructor(page) {
        this.page = page;
    }

    async signup(username, password) {

        // Wait for Sign Up modal
        await expect(
            this.page.locator(signuplocators.signupDialog)
        ).toBeVisible({
            timeout: 10000
        });

        // Enter credentials
        await this.page.fill(signuplocators.username, username);

        await this.page.fill(signuplocators.password, password);

        // Wait for Signup dialog
        const dialogPromise =
            this.page.waitForEvent('dialog');

        // Click Signup button
        await this.page.locator(signuplocators.signupBtn).click();

        // Handle alert
        const dialog =await dialogPromise;

        const message = dialog.message();

        console.log('Signup Message:', message);

        await dialog.accept();

        // Handle existing user
        if (message.includes('This user already exist')) {

            await this.page.locator(signuplocators.signupBtn).click();

            console.log('User already exists.');

            return;
        }

        // Success case
        if (message.includes('Sign up successful')) {
            console.log('Signup Successful');
        }
    }
}

module.exports = SignupPage;