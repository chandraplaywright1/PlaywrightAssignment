const { expect } = require('@playwright/test');
const productlocators = require('../locators/productLocators');

class ProductPage {

    constructor(page) {
        this.page = page;
    }

    async selectProduct(productName) {

        // Click product from home page
        await this.page.locator(productlocators.productTitle)
            .filter({ hasText: productName })
            .click();

        // Verify product details page opened
        await expect(
            this.page.locator(productlocators.productName)
        ).toContainText(
            productName,
            {
                timeout: 10000
            }
        );
    }

    async addToCart() {

    this.page.once('dialog', async dialog => {

        console.log('Add To Cart Message:', dialog.message());

        await dialog.accept();
    });

    await expect(
        this.page.locator(productlocators.addToCartBtn
)
    ).toBeVisible({
        timeout: 10000
    });

    await this.page.locator(productlocators.addToCartBtn).click();
}
}

module.exports = ProductPage;