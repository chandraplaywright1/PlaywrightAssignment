const { test } = require('@playwright/test');

const HomePage = require('../pages/HomePage');
const SignupPage = require('../pages/SignupPage');
const LoginPage = require('../pages/LoginPage');
const ProductPage = require('../pages/ProductPage');
const CartPage = require('../pages/CartPage');
const PlaceOrderPage = require('../pages/PlaceOrderPage');

const testData = require('../utils/testData');

test.setTimeout(120000);

test('Demoblaze Complete End-to-End Flow', async ({ page }) => {

const homePage = new HomePage(page);
const signupPage = new SignupPage(page);
const loginPage = new LoginPage(page);
const productPage = new ProductPage(page);
const cartPage = new CartPage(page);
const placeOrderPage = new PlaceOrderPage(page);
await homePage.navigate();

await homePage.clickSignup();

await signupPage.signup(
    testData.username,
    testData.password
);

await homePage.clickLogin();

await loginPage.login(
    testData.username,
    testData.password
);

await productPage.selectProduct(
    testData.productName
);

await productPage.addToCart();

await homePage.openCart();

await cartPage.verifyProduct(
    testData.productName
);

await cartPage.clickPlaceOrder();

await placeOrderPage.placeOrder(
    testData.orderDetails
);

await placeOrderPage.verifyOrderSuccess();
});