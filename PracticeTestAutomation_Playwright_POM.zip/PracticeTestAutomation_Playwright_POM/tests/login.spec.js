const { expect } = require('@playwright/test');
const { test } = require('../hooks/testHooks');
const data = require('../testData/loginData.json');

test.describe('Practice Test Automation - Login Validation', () => {
  test.beforeEach(async ({ loginPage }) => {
    await loginPage.open();
  });

  test('TC01 - Login with valid credentials', async ({ page, loginPage, successPage }) => {
    await loginPage.login(data.validUser.username, data.validUser.password);
    await expect(page).toHaveURL(new RegExp(data.expected.successUrlPart));
    await expect.poll(() => successPage.isSuccessPageDisplayed()).toBeTruthy();
    await expect(successPage.getHeading()).resolves.toContain(data.expected.successHeading);
  });

  test('TC02 - Login with invalid username', async ({ page, loginPage }) => {
    await loginPage.login(data.invalidUser.username, data.invalidUser.password);
    await expect(page).toHaveURL(/practice-test-login/);
    await expect.poll(() => loginPage.getErrorMessage()).toContain(data.expected.invalidUsernameMessage);
  });

  test('TC03 - Login with valid username and invalid password', async ({ page, loginPage }) => {
    await loginPage.login(data.validUser.username, data.invalidUser.password);
    await expect(page).toHaveURL(/practice-test-login/);
    await expect.poll(() => loginPage.getErrorMessage()).toContain(data.expected.invalidPasswordMessage);
  });

  test('TC04 - Login with blank credentials', async ({ page, loginPage }) => {
    await loginPage.clickSubmit();
    await expect(page).toHaveURL(/practice-test-login/);
  });
});
