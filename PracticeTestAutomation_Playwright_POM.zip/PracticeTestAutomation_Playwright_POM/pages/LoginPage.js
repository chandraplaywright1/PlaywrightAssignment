const { BasePage } = require('./BasePage');
const { LoginLocators } = require('../locators/LoginLocators');

class LoginPage extends BasePage {
  async open() { await this.goto('/practice-test-login/'); }
  async enterUsername(username) { await this.fill(LoginLocators.usernameInput, username); }
  async enterPassword(password) { await this.fill(LoginLocators.passwordInput, password); }
  async clickSubmit() { await this.click(LoginLocators.submitButton); }

  async login(username, password) {
    await this.enterUsername(username);
    await this.enterPassword(password);
    await this.clickSubmit();
  }

  async getErrorMessage() {
    await this.waitForVisible(LoginLocators.errorMessage);
    return this.getText(LoginLocators.errorMessage);
  }

  async isLoginPageDisplayed() { return this.isVisible(LoginLocators.submitButton); }
}
module.exports = { LoginPage };
