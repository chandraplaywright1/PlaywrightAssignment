class BasePage {
  constructor(page) { this.page = page; }

  async goto(url = '/') {
    await this.page.goto(url, { waitUntil: 'domcontentloaded' });
  }

  async click(locator) { await this.page.locator(locator).click(); }
  async fill(locator, value) { await this.page.locator(locator).fill(String(value)); }
  async getText(locator) { return (await this.page.locator(locator).first().innerText()).trim(); }
  async isVisible(locator) { return this.page.locator(locator).first().isVisible(); }
  async waitForVisible(locator) {
    await this.page.locator(locator).first().waitFor({ state: 'visible' });
  }
}
module.exports = { BasePage };
