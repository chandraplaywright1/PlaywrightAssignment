const { BasePage } = require('./BasePage');
const { SuccessLocators } = require('../locators/SuccessLocators');

class SuccessPage extends BasePage {
  async getHeading() {
     return this.getText(SuccessLocators.successHeading); 
    }

  async getSuccessMessage() {
     return this.getText(SuccessLocators.successMessage); 
    }

  async logout() {
     await this.click(SuccessLocators.logoutButton); 
    }
  async isSuccessPageDisplayed() { 
    return this.page.url().includes('logged-in-successfully'); 
  }
  
}
module.exports = { SuccessPage };
