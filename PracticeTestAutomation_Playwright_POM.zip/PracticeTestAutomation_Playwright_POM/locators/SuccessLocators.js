class SuccessLocators {
  static successHeading = 'h1';
  static successMessage = '.post-title';
  static logoutButton = 'a.wp-block-button__link';
}
module.exports = { SuccessLocators };
