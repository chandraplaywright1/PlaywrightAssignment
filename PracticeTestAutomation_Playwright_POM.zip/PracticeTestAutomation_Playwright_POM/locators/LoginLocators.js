class LoginLocators {
  static usernameInput = '#username';
  static passwordInput = '#password';
  static submitButton = '#submit';
  static errorMessage = '#error';
}
module.exports = { LoginLocators };
