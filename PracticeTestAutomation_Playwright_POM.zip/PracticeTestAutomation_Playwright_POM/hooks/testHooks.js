const { test: base } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');
const { SuccessPage } = require('../pages/SuccessPage');

const test = base.extend({
  loginPage: async ({ page }, use) => await use(new LoginPage(page)),
  successPage: async ({ page }, use) => await use(new SuccessPage(page))
});

module.exports = { test };
