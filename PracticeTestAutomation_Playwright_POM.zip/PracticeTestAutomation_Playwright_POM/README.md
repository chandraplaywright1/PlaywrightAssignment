# Practice Test Automation - Playwright JavaScript POM

Application:
https://practicetestautomation.com/practice-test-login/

## Coverage
- Valid login
- Invalid username
- Invalid password
- Blank credentials
- Success page validation
- Failure message validation

## Structure
locators/   -> selectors only
pages/      -> page objects and business actions
hooks/      -> custom Playwright fixtures
testData/   -> JSON test data
tests/      -> test scenarios
BasePage   -> reusable browser methods

## Install
npm install
npx playwright install chromium

## Run
npm test
npm run test:headed
npm run test:debug
npm run test:ui
npm run report

