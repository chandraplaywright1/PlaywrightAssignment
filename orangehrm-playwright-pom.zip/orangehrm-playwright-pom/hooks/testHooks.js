const { test: base, expect } = require('@playwright/test');
const LoginPage = require('../pages/LoginPage');
const DashboardPage = require('../pages/DashboardPage');
const SidebarPage = require('../pages/SidebarPage');
const EmployeePage = require('../pages/EmployeePage');
const testData = require('../testData/orangehrm.testdata.json');

const test = base.extend({
  testData: async ({}, use) => {
    await use(testData);
  },

  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },

  dashboardPage: async ({ page }, use) => {
    await use(new DashboardPage(page));
  },

  sidebarPage: async ({ page }, use) => {
    await use(new SidebarPage(page));
  },

  employeePage: async ({ page }, use) => {
    await use(new EmployeePage(page));
  }
});

module.exports = { test, expect };