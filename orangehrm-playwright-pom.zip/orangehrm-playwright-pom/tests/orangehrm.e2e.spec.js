const { test, expect } = require('../hooks/testHooks');

test.describe('OrangeHRM Admin - POM E2E Flow', () => {
  test.slow();
  test.setTimeout(120000);

  test.beforeEach(async ({ loginPage, testData }) => {
    await loginPage.open();
    await expect(loginPage.page).toHaveURL(/auth\/login/);
    await expect(loginPage.page.locator(loginPage.locators.loginButton)).toBeVisible();
  });

  test('Login -> navigate menus -> add employee -> search/filter -> logout', async ({
    loginPage,
    dashboardPage,
    sidebarPage,
    employeePage,
    testData
  }) => {
    // Login
    await loginPage.loginAndWait(
      testData.credentials.username,
      testData.credentials.password
    );

    // Dashboard validation
    await expect(dashboardPage.page).toHaveURL(/dashboard\/index/);
    await expect.poll(() => dashboardPage.isDashboardVisible()).toBeTruthy();

    // Persistent sidebar / menu navigation
    await expect.poll(() =>
      sidebarPage.isMenuVisible(testData.navigation.employeeMenu)
    ).toBeTruthy();

    await sidebarPage.navigateTo(testData.navigation.employeeMenu);
    await expect(employeePage.page).toHaveURL(/pim\/viewEmployeeList/);

    // Navigate another menu and return to PIM to validate reusable sidebar POM
    await sidebarPage.navigateTo(testData.navigation.leaveMenu);
    await expect(sidebarPage.page).toHaveURL(/leave\/viewLeaveList/);

    await sidebarPage.navigateTo(testData.navigation.employeeMenu);
    await expect(employeePage.page).toHaveURL(/pim\/viewEmployeeList/);

    // Add employee
    const uniqueLastName =
      `${testData.employee.lastNamePrefix}${Date.now().toString().slice(-6)}`;

    await employeePage.addEmployeeFromList(
      testData.employee.firstName,
      testData.employee.middleName,
      uniqueLastName
    );

    // Search / filter employee
    const fullEmployeeName = `${testData.employee.firstName} ${testData.employee.middleName} ${uniqueLastName}`;

    await employeePage.searchEmployee(fullEmployeeName);

    await expect.poll(() =>
      employeePage.isEmployeePresent(fullEmployeeName)
    ).toBeTruthy();

    // Logout
    await dashboardPage.logout();
    await expect(loginPage.page).toHaveURL(/auth\/login/);
    await expect(loginPage.page.locator(loginPage.locators.loginButton)).toBeVisible();
  });
});