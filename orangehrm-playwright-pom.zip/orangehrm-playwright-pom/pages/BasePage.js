class BasePage {
  constructor(page) {
    this.page = page;
  }

  async goto(path) {
    await this.page.goto(path, { waitUntil: 'domcontentloaded' });
  }

  async click(selector) {
    await this.page.locator(selector).click({ noWaitAfter: true });
  }

  async fill(selector, value) {
    const locator = this.page.locator(selector);
    await locator.waitFor({ state: 'visible', timeout: 15000 });
    await locator.fill(value);
  }

  async getText(selector) {
    return this.page.locator(selector).first().innerText();
  }

  async isVisible(selector) {
    return this.page.locator(selector).first().isVisible();
  }

  async waitForUrl(urlOrPattern) {
    await this.page.waitForURL(urlOrPattern, { waitUntil: 'domcontentloaded' });
  }
}

module.exports = BasePage;