const BasePage = require('./BasePage');
const locators = require('../locators/employee.locators');

class EmployeePage extends BasePage {
  constructor(page) {
    super(page);
    this.locators = locators;
  }

  async clickAdd() {
    await this.page.locator(this.locators.addButton).click({ noWaitAfter: true });
    await this.page.waitForURL(/pim\/addEmployee/, { waitUntil: 'domcontentloaded' });
  }

  async addEmployee(firstName, middleName, lastName) {
    await this.fill(this.locators.firstName, firstName);
    if (middleName) {
      await this.fill(this.locators.middleName, middleName);
    }
    await this.fill(this.locators.lastName, lastName);
    await this.click(this.locators.saveButton);
    await this.page.waitForURL(/pim\/viewPersonalDetails|pim\/viewEmployeeList|pim\/viewEmployee/, { waitUntil: 'domcontentloaded' });
    await this.goto('/web/index.php/pim/viewEmployeeList');
    await this.page.waitForURL(/pim\/viewEmployeeList/, { waitUntil: 'domcontentloaded' });
  }

  async addEmployeeFromList(firstName, middleName, lastName) {
    await this.clickAdd();
    await this.addEmployee(firstName, middleName, lastName);
  }

  async searchEmployee(employeeName) {
    await this.fill(this.locators.employeeNameSearch, employeeName);
    await this.click(this.locators.searchButton);
    await this.page.locator(this.locators.recordsFound).waitFor({ state: 'visible' });
    await this.page.waitForTimeout(700);
  }

  async isEmployeePresent(employeeName) {
    const nameParts = employeeName.split(/\s+/).filter(Boolean);
    let row = this.page.locator(this.locators.tableRow);

    for (const part of nameParts) {
      row = row.filter({ hasText: part });
    }

    return row.first().isVisible();
  }

  async resetSearch() {
    await this.click(this.locators.resetButton);
  }

  async getEmployeeListTitle() {
    return this.getText(this.locators.employeeListTitle);
  }
}

module.exports = EmployeePage;