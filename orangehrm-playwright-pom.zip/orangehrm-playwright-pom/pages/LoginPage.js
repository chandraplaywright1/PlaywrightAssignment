const BasePage = require('./BasePage');
const locators = require('../locators/login.locators');

class LoginPage extends BasePage {
  constructor(page) {
    super(page);
    this.locators = locators;
  }

  async open() {
    await this.goto('/web/index.php/auth/login');
  }

  async login(username, password) {
    await this.fill(this.locators.username, username);
    await this.fill(this.locators.password, password);
    await this.click(this.locators.loginButton);
  }

  async loginAndWait(username, password) {
    await this.login(username, password);
    await this.page.waitForURL(/dashboard\/index/, { waitUntil: 'domcontentloaded' });
  }

  async isLoginPageVisible() {
    return this.isVisible(this.locators.loginButton);
  }

  async getLoginError() {
    return this.getText(this.locators.loginError);
  }
}

module.exports = LoginPage;