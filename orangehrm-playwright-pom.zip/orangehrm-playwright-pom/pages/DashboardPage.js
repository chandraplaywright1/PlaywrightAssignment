const BasePage = require('./BasePage');
const locators = require('../locators/dashboard.locators');

class DashboardPage extends BasePage {
  constructor(page) {
    super(page);
    this.locators = locators;
  }

  async isDashboardVisible() {
    return this.page.locator(this.locators.dashboardTitle).filter({ hasText: 'Dashboard' }).isVisible();
  }

  async logout() {
    await this.click(this.locators.userDropdown);
    await this.page.locator(this.locators.logoutLink).click({ noWaitAfter: true });
    await this.page.waitForURL(/auth\/login/, { waitUntil: 'domcontentloaded' });
  }
}

module.exports = DashboardPage;