const BasePage = require('./BasePage');
const locators = require('../locators/common.locators');

class SidebarPage extends BasePage {
  constructor(page) {
    super(page);
    this.locators = locators;
  }

  async navigateTo(menuName) {
    const routeMap = {
      PIM: /pim\/viewEmployeeList|pim\/viewPimModule/,
      Leave: /leave\/viewLeaveList|leave\/viewLeaveModule/,
      Time: /time\/viewTimeModule/
    };

    await this.page.locator(this.locators.menuItemByText(menuName)).click({ noWaitAfter: true });
    await this.page.waitForURL(routeMap[menuName] || /.*/, { waitUntil: 'domcontentloaded' });
  }

  async isMenuVisible(menuName) {
    return this.page.locator(this.locators.menuItemByText(menuName)).isVisible();
  }
}

module.exports = SidebarPage;