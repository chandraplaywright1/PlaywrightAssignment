module.exports = {
  username: 'input[name="username"]',
  password: 'input[name="password"]',
  loginButton: 'button[type="submit"]',
  loginError: '.oxd-alert-content-text',
  forgotPassword: '.orangehrm-login-forgot-header'
};