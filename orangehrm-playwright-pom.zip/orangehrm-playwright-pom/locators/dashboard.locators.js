module.exports = {
  dashboardTitle: '.oxd-topbar-header-breadcrumb h6',
  userDropdown: '.oxd-userdropdown-tab',
  logoutLink: 'a:has-text("Logout")'
};