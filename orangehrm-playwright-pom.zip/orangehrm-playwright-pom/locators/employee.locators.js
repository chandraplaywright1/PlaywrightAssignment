module.exports = {
  addButton: 'button:has-text("Add")',
  firstName: 'input[name="firstName"]',
  middleName: 'input[name="middleName"]',
  lastName: 'input[name="lastName"]',
  employeeId: '.oxd-input-group:has(label:has-text("Employee Id")) input',
  saveButton: 'button[type="submit"]',
  employeeListTitle: '.oxd-topbar-header-breadcrumb h6',
  employeeNameSearch: '.oxd-input-group:has(label:has-text("Employee Name")) input',
  searchButton: 'button:has-text("Search")',
  resetButton: 'button:has-text("Reset")',
  recordsFound: '.orangehrm-horizontal-padding span',
  tableBody: '.oxd-table-body',
  tableRow: '.oxd-table-card',
  noRecords: '.oxd-table-body .oxd-table-card',
  requiredError: '.oxd-input-field-error-message'
};