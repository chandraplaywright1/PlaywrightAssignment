module.exports = {
  sidebar: '.oxd-sidepanel',
  menuItems: '.oxd-main-menu-item',
  menuItemByText: (text) => `.oxd-main-menu-item:has-text("${text}")`
};