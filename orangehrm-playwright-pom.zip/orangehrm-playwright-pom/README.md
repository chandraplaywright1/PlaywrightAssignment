# OrangeHRM Playwright JavaScript POM Framework

A maintainable Playwright JavaScript Page Object Model framework for the OrangeHRM demo application.

## Flow automated

1. Login with test data
2. Verify dashboard
3. Navigate through sidebar menus
4. Add a new employee
5. Search/filter employee
6. Logout
7. Verify login page

## Project structure

```text
orangehrm-playwright-pom/
├── locators/
│   ├── login.locators.js
│   ├── dashboard.locators.js
│   ├── employee.locators.js
│   └── common.locators.js
├── pages/
│   ├── BasePage.js
│   ├── LoginPage.js
│   ├── DashboardPage.js
│   ├── EmployeePage.js
│   └── SidebarPage.js
├── hooks/
│   └── testHooks.js
├── testData/
│   └── orangehrm.testdata.json
├── tests/
│   └── orangehrm.e2e.spec.js
├── playwright.config.js
├── package.json
└── README.md
```

## Prerequisites

- Node.js 18+
- npm

## Install

```bash
npm install
npx playwright install
```

## Execute

```bash
npm test
```

Headed:

```bash
npm run test:headed
```

Debug:

```bash
npm run test:debug
```

HTML report:

```bash
npm run report
```

## Notes

The demo currently exposes the standard demo credentials shown on the OrangeHRM demo login page. They are stored in JSON test data for easy maintenance.

Locators are intentionally centralized under `locators/`. Page classes consume those locator definitions instead of embedding selectors throughout tests.

The test uses a unique employee name generated at runtime so repeated execution does not depend on a fixed employee record.
